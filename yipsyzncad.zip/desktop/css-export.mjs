import { validateProject } from '../dist/model.js';
import { makeGeometry } from '../dist/viewport.js';
const sub=(a,b)=>a.map((v,i)=>v-b[i]);
const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const norm=a=>{const n=Math.hypot(...a);return a.map(v=>v/n);};
const num=n=>String(+n.toFixed(6));
const vec=a=>a.map(num).join(' ');
function transform(p,o){
 let [x,y,z]=p;const [rx,ry,rz]=o.rotation.map(n=>n*Math.PI/180);
 [y,z]=[y*Math.cos(rx)-z*Math.sin(rx),y*Math.sin(rx)+z*Math.cos(rx)];
 [x,z]=[x*Math.cos(ry)+z*Math.sin(ry),-x*Math.sin(ry)+z*Math.cos(ry)];
 return [x*Math.cos(rz)-y*Math.sin(rz),x*Math.sin(rz)+y*Math.cos(rz),z].map((v,i)=>v+o.position[i]);
}
// Only proven-convex primitives enter this first exporter. Compound assets must
// acquire an explicit decomposition; treating their triangle soup as one brush is invalid.
export function brushPlanes(o){
 if(!['block','platform','wall','ramp','surf'].includes(o.type))throw Error('Unsupported asset: '+o.name+' ('+o.type+'). First export supports blocks, platforms, walls, ramps and straight surf ramps.');
 if(o.type==='surf' && o.surf.bend!==0)throw Error('Curved surf export is not implemented: '+o.name);
 if(Math.min(...o.size)<4)throw Error('Export pieces must be at least 4 units thick: '+o.name);
 const faces=makeGeometry(o).faces.map(f=>f.points.map(p=>transform(p,o)));
 const points=faces.flat(),planes=[];
 const center=points.reduce((s,p)=>s.map((v,i)=>v+p[i]/points.length),[0,0,0]);
 for(let p of faces){
  let n=norm(cross(sub(p[1],p[0]),sub(p[2],p[0])));
  if(!n.every(Number.isFinite))throw Error('Degenerate surface: '+o.name);
  if(dot(n,sub(center,p[0]))>0){p=[p[0],p[2],p[1]];n=n.map(v=>-v);}
  const d=dot(n,p[0]);
  if(points.some(v=>dot(n,v)-d>.001))throw Error('Non-convex brush: '+o.name);
  if(!planes.some(q=>Math.abs(q.d-d)<.0001 && dot(q.n,n)>.99999999))planes.push({p,n,d});
 }
 return planes;
}
export function exportCss(project){
 const p=validateProject(project),objects=p.objects.filter(o=>o.visible);
 if(!objects.length)throw Error('Map has no visible objects.');
 if(!p.playtest)throw Error('Set and save a playtest spawn in the editor before exporting.');
 const warnings=['Prototype export: editor colours, paint, pulse effects and skybox are replaced with CS:Source developer materials and a sealed test room.'];
 const brushes=objects.map(o=>{
  if(!o.collision)throw Error('Non-solid asset export is not implemented: '+o.name);
  return brushPlanes(o);
 });
 const points=brushes.flatMap(b=>b.flatMap(s=>s.p));
 const lo=[0,1,2].map(i=>Math.floor(points.reduce((v,p)=>Math.min(v,p[i]),Infinity)-128));
 const hi=[0,1,2].map(i=>Math.ceil(points.reduce((v,p)=>Math.max(v,p[i]),-Infinity)+256));
 if([...lo,...hi].some(v=>Math.abs(v)>15000))throw Error('Map exceeds the prototype CS:Source bounds (+/-15,000 units including enclosure). Move or shrink it.');
 const spawn=p.playtest.spawn.position.map((v,i)=>v+(i===2?1:0));
 if(spawn.some((v,i)=>v<lo[i]+32||v>hi[i]-80))throw Error('Spawn is outside the test enclosure.');
 // Reject a player box intersecting a brush, using conservative plane support.
 if(brushes.some(b=>b.every(s=>dot(s.n,[spawn[0],spawn[1],spawn[2]+36])-s.d <= Math.abs(s.n[0])*16+Math.abs(s.n[1])*16+Math.abs(s.n[2])*36)))throw Error('Spawn overlaps map geometry. Move it to clear ground with headroom.');
 let id=1;
 const kv=(k,v)=>'"'+k+'" "'+v+'"\n';
 function solid(planes,material){return 'solid\n{\n'+kv('id',id++)+planes.map(s=>{
  // Valve plane convention is cross(p0-p1,p2-p1), opposite a triangle normal.
  const pp=[s.p[0],s.p[2],s.p[1]];
  const ref=Math.abs(s.n[2])<.9?[0,0,1]:[0,1,0];
  const u=norm(cross(ref,s.n)),v=cross(s.n,u);
  return 'side\n{\n'+kv('id',id++)+kv('plane',pp.map(p=>'('+vec(p)+')').join(' '))+kv('material',material)+kv('uaxis','['+vec(u)+' 0] 0.25')+kv('vaxis','['+vec(v)+' 0] 0.25')+kv('rotation',0)+kv('lightmapscale',32)+kv('smoothing_groups',0)+'}\n';
 }).join('')+'}\n';}
 const worldId=id++;
 let solids=brushes.map(b=>solid(b,'dev/dev_measuregeneric01b')).join('');
 // Six touching world brushes seal the map. This adds a test-room floor, not a kill trigger.
 for(let axis=0;axis<3;axis++)for(const side of [-1,1]){
  const size=hi.map((v,i)=>v-lo[i]+64),position=hi.map((v,i)=>(v+lo[i])/2);
  size[axis]=32;position[axis]=(side<0?lo[axis]-16:hi[axis]+16);
  solids+=solid(brushPlanes({type:'block',name:'Enclosure',size,position,rotation:[0,0,0]}),'dev/dev_measuregeneric01b');
 }
 const entity=(cls,props)=>'entity\n{\n'+kv('id',id++)+kv('classname',cls)+Object.entries(props).map(([k,v])=>kv(k,v)).join('')+'}\n';
 const vmf='versioninfo\n{\n"editorversion" "400"\n"editorbuild" "0"\n"mapversion" "1"\n"formatversion" "100"\n"prefab" "0"\n}\nworld\n{\n'+kv('id',worldId)+kv('classname','worldspawn')+kv('mapversion',1)+kv('skyname','sky_day01_01')+solids+'}\n'+entity('info_player_counterterrorist',{origin:vec(spawn),angles:'0 '+num(p.playtest.spawn.yaw)+' 0'})+entity('light',{origin:vec([(lo[0]+hi[0])/2,(lo[1]+hi[1])/2,hi[2]-48]),_light:'255 244 225 800'});
 return {vmf,warnings,brushCount:brushes.length+6};
}

