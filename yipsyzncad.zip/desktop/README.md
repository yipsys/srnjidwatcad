# CS:Source desktop prototype

The usage terms in the main README apply.

## Credits

sornin — Developer.

## Open it
Double-click `BhopBuilder.exe` in the main project folder. Keep `desktop/`, `dist/`, `server.mjs` and `package.json` beside it.

The launcher uses Microsoft Edge and Node.js already installed on your PC. It can also find the existing Codex Node runtime. It does not download software. This is a native Windows controller with the editor in a separate Edge app window, not a self-contained installer. The executable is unsigned.

## Compile a first map
1. Install Counter-Strike: Source and its matching map tools through Steam. CS2 tools are not compatible.
2. Open the launcher and click **Open map editor**.
3. Open `desktop/examples/css-starter.bhop.json`, or build a small map using only the supported pieces below.
4. Set a playtest spawn in clear space and save the project to a `.bhop.json` file.
5. In the launcher, browse to that saved project.
6. Choose the installed game's `cstrike` directory, containing `gameinfo.txt` with Steam app ID 240.
7. Choose the matching compiler directory containing `vbsp.exe`, `vvis.exe` and `vrad.exe`. Use tools from your trusted game installation.
8. Choose an output directory, then click **Compile to .bsp**.
9. Each attempt gets a new subfolder containing a VMF, export notes and a build log. A successful pipeline produces `bhop_map.bsp`. Inspect the log and test the result in CS:Source before sharing.

To try the resulting BSP manually, copy it into your CS:Source `cstrike/maps` directory without overwriting an existing map. Launch the game and load `map bhop_map` in its developer console. This prototype supplies one CT spawn for solo testing.

## Current limits
- Supports solid visible blocks, platforms, walls, ramps and straight surf ramps.
- Curved surf ramps, scenery, compound assets and non-solid objects are rejected explicitly.
- Hidden objects are omitted. Editor paint, colours, pulse and skyboxes are not exported.
- Uses developer materials and adds a sealed room, a floor and one light. It does not add bhop timers, reset triggers, checkpoints, multiplayer spawns or game modes.
- Large station courses containing scenery cannot currently compile with this exporter.
- The app runs installed native tools in order: VBSP, VVIS, VRAD. It does not merely change the project file extension.
- Successful process exits and a BSP v20 header are checked, but those checks do not prove in-game correctness.
- Real compilation and in-game validation have NOT been completed: the development machine has no matching CS:Source tools installed.
- Save editable projects explicitly. The launcher opens a new local port, so browser drafts from another editor session may not appear.
- Keep the controller open while editing. Closing it stops its local server.
- No online compiler, hosting service, tool redistribution or CS2 support is included.

## Rebuild the launcher
From the project folder in Windows PowerShell:

```powershell
& "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe" /nologo /target:winexe /out:BhopBuilder.exe /win32icon:desktop\assets\bhop-builder-icon.ico /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Web.Extensions.dll desktop\BuilderApp.cs
```

Node tests cover geometry rejection, VMF structure and compiler orchestration using simulated tool results. Run `npm test` for the complete suite. These simulations do not run Valve's compiler.



