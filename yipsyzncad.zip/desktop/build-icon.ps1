# Package the generated PNG as a multi-resolution Windows icon.
Add-Type -AssemblyName System.Drawing
$assetDir=Join-Path $PSScriptRoot 'assets'
$source=[System.Drawing.Image]::FromFile((Join-Path $assetDir 'bhop-builder-icon.png'))
$sizes=@(16,32,48,64,128,256)
$frames=@()
try {
 foreach($size in $sizes){
  $bitmap=New-Object System.Drawing.Bitmap($size,$size)
  $graphics=[System.Drawing.Graphics]::FromImage($bitmap)
  $graphics.InterpolationMode=[System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $graphics.CompositingQuality=[System.Drawing.Drawing2D.CompositingQuality]::HighQuality
  $graphics.PixelOffsetMode=[System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
  $graphics.DrawImage($source,0,0,$size,$size)
  $memory=New-Object System.IO.MemoryStream
  $bitmap.Save($memory,[System.Drawing.Imaging.ImageFormat]::Png)
  $frames+=,@($memory.ToArray())
  $memory.Dispose(); $graphics.Dispose(); $bitmap.Dispose()
 }
 $stream=[System.IO.File]::Create((Join-Path $assetDir 'bhop-builder-icon.ico'))
 $writer=New-Object System.IO.BinaryWriter($stream)
 try {
  $writer.Write([uint16]0);$writer.Write([uint16]1);$writer.Write([uint16]$sizes.Count)
  $offset=6+16*$sizes.Count
  for($i=0;$i -lt $sizes.Count;$i++){
   $dimension=if($sizes[$i] -eq 256){0}else{$sizes[$i]}
   $writer.Write([byte]$dimension);$writer.Write([byte]$dimension)
   $writer.Write([byte]0);$writer.Write([byte]0)
   $writer.Write([uint16]1);$writer.Write([uint16]32)
   $writer.Write([uint32]$frames[$i].Length);$writer.Write([uint32]$offset)
   $offset+=$frames[$i].Length
  }
  foreach($frame in $frames){$writer.Write([byte[]]$frame)}
 } finally {$writer.Dispose();$stream.Dispose()}
} finally {$source.Dispose()}
