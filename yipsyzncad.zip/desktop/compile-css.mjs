import { readFile,writeFile,mkdir,stat,open } from 'node:fs/promises';
import { resolve,join,basename } from 'node:path';
import { spawn } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { parseProject } from '../dist/model.js';
import { exportCss } from './css-export.mjs';
export async function runTool(exe,args,log){
 await new Promise((ok,fail)=>{
  const child=spawn(exe,args,{shell:false,windowsHide:true,cwd:resolve(exe,'..')});
  let ended=false;
  const timer=setTimeout(()=>{child.kill();finish(Error('Compiler exceeded 30 minutes.'));},30*60*1000);
  function finish(error){if(ended)return;ended=true;clearTimeout(timer);error?fail(error):ok();}
  child.stdout.on('data',d=>log(d.toString()));child.stderr.on('data',d=>log(d.toString()));
  child.on('error',finish);child.on('close',code=>finish(code===0?null:Error(basename(exe)+' failed (exit '+code+'). See build.log.')));
 });
}
export async function compileProject(config,{execute=runTool,log=console.log}={}){
 for(const key of ['project','game','tools','output'])if(typeof config[key]!=='string'||!config[key])throw Error('Missing '+key+' path.');
 const game=resolve(config.game),tools=resolve(config.tools);
 if(basename(game).toLowerCase()!=='cstrike')throw Error('Choose the Counter-Strike Source/cstrike folder, not CS2.');
 const info=await readFile(join(game,'gameinfo.txt'),'utf8');
 if(!/\bSteamAppId"?\s+"?240\b/i.test(info))throw Error('gameinfo.txt must identify CS:Source (Steam app 240).');
 for(const name of ['vbsp','vvis','vrad'])if(!(await stat(join(tools,name+'.exe')).catch(()=>null))?.isFile())throw Error('Missing '+name+'.exe. Select your installed CS:Source compiler folder.');
 if((await stat(config.project)).size>8*1024*1024)throw Error('Project exceeds 8 MB.');
 const result=exportCss(parseProject(await readFile(config.project,'utf8')));
 await mkdir(resolve(config.output),{recursive:true});
 const job=join(resolve(config.output),'bhop_'+Date.now()+'_'+Math.random().toString(16).slice(2,8));
 await mkdir(job);const vmf=join(job,'bhop_map.vmf'),bsp=join(job,'bhop_map.bsp');
 await writeFile(vmf,result.vmf);await writeFile(join(job,'export-notes.txt'),result.warnings.join('\n'));
 const handle=await open(join(job,'build.log'),'w');let failure=false;let pending=Promise.resolve();let logError;
 const write=s=>{log(s);pending=pending.then(()=>handle.write(s+'\n')).catch(e=>{logError=e;});if(/\bleaked\b|\*\*\*\*\s*error/i.test(s))failure=true;};
 try{
  result.warnings.forEach(write);
  for(const tool of ['vbsp','vvis','vrad']){
   write('Running '+tool+'...');
   await execute(join(tools,tool+'.exe'),['-game',game,tool==='vbsp'?vmf:bsp],write);
   if(failure)throw Error('Compiler reported a leak or error. See build.log.');
  }
  const file=await open(bsp,'r');let header;
  try{header=Buffer.alloc(8);await file.read(header,0,8,0);}finally{await file.close();}
  if(header.toString('ascii',0,4)!=='VBSP'||header.readInt32LE(4)!==20)throw Error('Output is not a CS:Source BSP version 20.');
  write('Build completed: '+bsp+'\nTest this map in CS:Source before sharing.');return bsp;
 }finally{await pending;await handle.close();if(logError)throw logError;}
}
if(process.argv[1] && import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
 try{await compileProject(JSON.parse(await readFile(process.argv[2],'utf8')));}catch(e){console.error(e.message);process.exitCode=1;}
}

