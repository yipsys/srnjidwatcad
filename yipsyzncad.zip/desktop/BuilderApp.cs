using System;
using System.IO;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;

class BuilderApp : Form {
 string root=AppDomain.CurrentDomain.BaseDirectory;
 TextBox project=new TextBox(),game=new TextBox(),tools=new TextBox(),output=new TextBox(),log=new TextBox();
 Process server,compiler; Button build; bool busy;
 string configFile;
 [STAThread] static void Main(){Application.EnableVisualStyles();Application.Run(new BuilderApp());}
 public BuilderApp(){
  Icon=Icon.ExtractAssociatedIcon(Application.ExecutablePath);
  Text="Bhop Builder - CS:Source desktop prototype";Width=860;Height=700;MinimumSize=new Size(760,620);StartPosition=FormStartPosition.CenterScreen;
  var panel=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=3,RowCount=10,Padding=new Padding(18)};
  panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,160));panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,85));Controls.Add(panel);
  var title=new Label{Text="BHOP BUILDER  |  Developer: sornin",AutoSize=true,Font=new Font("Segoe UI",15,FontStyle.Bold)};panel.Controls.Add(title,0,0);panel.SetColumnSpan(title,3);
  var open=new Button{Text="Open map editor",AutoSize=true};open.Click+=(s,e)=>OpenEditor();panel.Controls.Add(open,0,1);panel.SetColumnSpan(open,3);
  var help=new Label{Text="Save a .bhop.json project in the editor, then choose it below.\nCompile prototype: blocks, platforms, walls, ramps and STRAIGHT surf ramps.\nPlain test textures; generated enclosing room. Curved ramps/scenery are not supported yet.",AutoSize=true,Padding=new Padding(0,10,0,10)};panel.Controls.Add(help,0,2);panel.SetColumnSpan(help,3);
  AddRow(panel,3,"Saved project",project,true);AddRow(panel,4,"CS:Source cstrike folder",game,false);AddRow(panel,5,"Compiler bin folder",tools,false);AddRow(panel,6,"Output folder",output,false);
  output.Text=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"Bhop Builder Maps");
  build=new Button{Text="Compile to .bsp",AutoSize=true};build.Click+=(s,e)=>Compile();panel.Controls.Add(build,0,7);
  var browse=new Button{Text="Open output folder",AutoSize=true};browse.Click+=(s,e)=>{if(Directory.Exists(output.Text))Process.Start("explorer.exe",Quote(output.Text));};panel.Controls.Add(browse,1,7);
  log.Multiline=true;log.ReadOnly=true;log.ScrollBars=ScrollBars.Vertical;log.Dock=DockStyle.Fill;log.Font=new Font("Consolas",10);panel.Controls.Add(log,0,8);panel.SetColumnSpan(log,3);panel.RowStyles.Clear();for(int i=0;i<8;i++)panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));panel.RowStyles.Add(new RowStyle(SizeType.Percent,100));
  var note=new Label{Text="Uses installed Node.js and Edge. Install CS:Source tools through Steam. No tools are downloaded.\nThis launcher is unsigned. Compilation has not yet been verified in CS:Source.",AutoSize=true};panel.Controls.Add(note,0,9);panel.SetColumnSpan(note,3);
  FormClosing+=(s,e)=>{if(busy){MessageBox.Show("Wait for compilation to finish before closing the app.");e.Cancel=true;return;}if(server!=null&&!server.HasExited)server.Kill();};
 }
 void AddRow(TableLayoutPanel panel,int row,string label,TextBox box,bool file){
  panel.Controls.Add(new Label{Text=label,AutoSize=true,Anchor=AnchorStyles.Left},0,row);box.Dock=DockStyle.Fill;panel.Controls.Add(box,1,row);
  var pick=new Button{Text="Browse",AutoSize=true};panel.Controls.Add(pick,2,row);
  pick.Click+=(s,e)=>{if(file){using(var d=new OpenFileDialog{Filter="Bhop project (*.bhop.json)|*.bhop.json|JSON (*.json)|*.json"})if(d.ShowDialog()==DialogResult.OK)box.Text=d.FileName;}else{using(var d=new FolderBrowserDialog())if(d.ShowDialog()==DialogResult.OK)box.Text=d.SelectedPath;}};
 }
 static string Quote(string s){return "\""+s.Replace("\"", "\\\"").TrimEnd('\\')+"\"";}
 string Node(){
  var bundled=Path.Combine(root,"runtime","node.exe");if(File.Exists(bundled))return bundled;
  foreach(var dir in (Environment.GetEnvironmentVariable("PATH")??"").Split(';')){try{var p=Path.Combine(dir.Trim('"'),"node.exe");if(File.Exists(p))return p;}catch{}}
  var local=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),".cache","codex-runtimes","codex-primary-runtime","dependencies","node","bin","node.exe");if(File.Exists(local))return local;
  throw new Exception("Node.js was not found. Install Node.js or provide runtime/node.exe. This app does not download it automatically.");
 }
 void Log(string s){if(IsDisposed)return;if(InvokeRequired){BeginInvoke(new Action<string>(Log),s);return;}log.AppendText(s+Environment.NewLine);}
 Process StartNode(string args){var p=new Process();p.StartInfo=new ProcessStartInfo(Node(),args){UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=root,RedirectStandardOutput=true,RedirectStandardError=true};return p;}
 async void OpenEditor(){try{
  string edge=null;foreach(var dir in new[]{Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)}){var p=Path.Combine(dir,"Microsoft","Edge","Application","msedge.exe");if(File.Exists(p)){edge=p;break;}}
  if(edge==null)throw new Exception("Microsoft Edge was not found.");
  if(server!=null&&!server.HasExited){MessageBox.Show("The editor server is already running. Use the editor window you opened, or close and reopen this launcher.");return;}
  var listener=new TcpListener(IPAddress.Loopback,0);listener.Start();int port=((IPEndPoint)listener.LocalEndpoint).Port;listener.Stop();
  server=StartNode(Quote(Path.Combine(root,"server.mjs")));server.StartInfo.EnvironmentVariables["BHOP_PORT"]=port.ToString();server.OutputDataReceived+=(s,e)=>{if(e.Data!=null)Log(e.Data);};server.ErrorDataReceived+=(s,e)=>{if(e.Data!=null)Log(e.Data);};server.Start();server.BeginOutputReadLine();server.BeginErrorReadLine();
  string url="http://127.0.0.1:"+port+"/";bool ready=false;
  for(int i=0;i<30;i++){if(server.HasExited)throw new Exception("Local editor server failed to start.");try{using(var client=new WebClient()){await client.DownloadStringTaskAsync(url);ready=true;break;}}catch{}await System.Threading.Tasks.Task.Delay(100);}
  if(!ready)throw new Exception("Editor server did not respond.");
  Process.Start(new ProcessStartInfo(edge,"--app="+url){UseShellExecute=false});Log("Editor opened. Save a project before compiling. This session uses a separate browser origin; open your saved project to continue existing work.");
 }catch(Exception e){Log(e.Message);}}
 void Compile(){if(busy)return;try{
  var config=new Dictionary<string,string>{{"project",project.Text},{"game",game.Text},{"tools",tools.Text},{"output",output.Text}};
  configFile=Path.Combine(Path.GetTempPath(),"bhop-build-"+Guid.NewGuid().ToString("N")+".json");File.WriteAllText(configFile,new JavaScriptSerializer().Serialize(config));
  compiler=StartNode(Quote(Path.Combine(root,"desktop","compile-css.mjs"))+" "+Quote(configFile));compiler.EnableRaisingEvents=true;
  compiler.OutputDataReceived+=(s,e)=>{if(e.Data!=null)Log(e.Data);};compiler.ErrorDataReceived+=(s,e)=>{if(e.Data!=null)Log(e.Data);};
  compiler.Exited+=(s,e)=>{compiler.WaitForExit();int code=compiler.ExitCode;try{File.Delete(configFile);}catch{}BeginInvoke(new Action(()=>{busy=false;build.Enabled=true;Log(code==0?"Compilation finished. Open the output folder.":"Compilation failed. Details are shown above.");}));};
  busy=true;build.Enabled=false;log.Clear();compiler.Start();compiler.BeginOutputReadLine();compiler.BeginErrorReadLine();
 }catch(Exception e){busy=false;build.Enabled=true;if(configFile!=null)try{File.Delete(configFile);}catch{}Log(e.Message);}}
}




