import test from 'node:test';
import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import { createTriangleTree, hitTriangleTree } from '../dist/triangle-tree.js';
import { createObject } from '../dist/model.js';
import { reshapeSurf } from '../dist/surf.js';
import { EditorViewport } from '../dist/viewport.js';

const subtract = (a, b) => a.map((value, axis) => value - b[axis]);
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const normal = a => a.map(value => value / Math.hypot(...a));
function bruteHit(ray, triangles, maxDistance = Infinity) {
  let closest = maxDistance, result = null;
  for (let index = 0; index < triangles.length; index += 3) {
    const a = triangles[index], b = triangles[index + 1], c = triangles[index + 2];
    const edge1 = subtract(b, a), edge2 = subtract(c, a), h = cross(ray.direction, edge2), determinant = dot(edge1, h);
    if (Math.abs(determinant) < 1e-8) continue;
    const inv = 1 / determinant, s = subtract(ray.origin, a), u = inv * dot(s, h);
    if (u < 0 || u > 1) continue;
    const q = cross(s, edge1), v = inv * dot(ray.direction, q);
    if (v < 0 || u + v > 1) continue;
    const distance = inv * dot(edge2, q);
    if (distance > 1e-5 && distance <= maxDistance && (!result || distance < closest)) {
      closest = distance; result = { index, distance };
    }
  }
  return result;
}
function compare(ray, triangles, tree, maxDistance) {
  const expected = bruteHit(ray, triangles, maxDistance);
  const actual = hitTriangleTree(ray, tree, maxDistance);
  assert.deepEqual(actual, expected);
}
function randomGenerator(seed = 41243) {
  return () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 2 ** 32; };
}
function nativeTriangles(object) {
  return Object.create(EditorViewport.prototype)._objectData(object).triangles;
}
function triangle(z = 0) { return [[0, 0, z], [10, 0, z], [0, 10, z]]; }

test('triangle tree preserves nearest two-sided hits, flat indices, equal-depth order and distance limits', () => {
  const triangles = [...triangle(0), ...triangle(10), ...triangle(10), ...triangle(-20)];
  const tree = createTriangleTree(triangles);
  const ray = { origin: [2, 2, 30], direction: [0, 0, -1] };
  assert.deepEqual(hitTriangleTree(ray, tree), { index: 3, distance: 20 });
  assert.equal(hitTriangleTree(ray, tree, 19), null);
  assert.deepEqual(hitTriangleTree(ray, tree, 20), { index: 3, distance: 20 });
  assert.deepEqual(hitTriangleTree({ origin: [2, 2, -30], direction: [0, 0, 1] }, tree), { index: 9, distance: 10 });
  for (const origin of [[0, 0, 30], [10, 0, 30], [0, 10, 30], [10, 10, 30], [2, 2, 10]]) compare({ origin, direction: [0, 0, -1] }, triangles, tree);
  assert.equal(hitTriangleTree(ray, createTriangleTree([])), null);
});

test('parallel rays, origins within bounds and near-parallel finite rays match exact triangles', () => {
  const triangles = [...triangle(), ...triangle(30)];
  const tree = createTriangleTree(triangles);
  for (const ray of [
    { origin: [2, 2, 20], direction: [0, 0, 1] },
    { origin: [2, 2, 20], direction: [0, 0, -1] },
    { origin: [11, 2, 20], direction: [0, 0, -1] },
    { origin: [2, 2, 20], direction: [1, 0, 0] },
    { origin: [2, 2, 20], direction: [-1, 0, 0] },
    { origin: [-1e-10, 2, 20], direction: normal([1e-11, 0, -1]) },
  ]) compare(ray, triangles, tree);
  const surfaceRay = { origin: [2, 2, 1e-6], direction: [0, 0, -1] };
  assert.equal(hitTriangleTree(surfaceRay, tree), null, 'same near-surface rejection as original picker');
});

test('tree agrees with original brute picking on blocks, curved ramps and detailed temples in world space', () => {
  const block = createObject('block', [130, -270, 54]); block.rotation = [13, -29, 43];
  const ramp = createObject('surf', [-140, 320, 152]);
  Object.assign(ramp, reshapeSurf(ramp, { bend: 110, length: 1200, slope: 55 })); ramp.rotation = [0, 0, 37];
  const temple = createObject('egypttemple', [320, -160, 320]); temple.rotation = [0, 0, 90];
  const random = randomGenerator();
  for (const object of [block, ramp, temple]) {
    const triangles = nativeTriangles(object), tree = createTriangleTree(triangles);
    for (let i = 0; i < 140; i++) {
      const origin = [object.position[0] + (random() - .5) * 4000, object.position[1] + (random() - .5) * 4000, object.position[2] + 1400];
      const target = [object.position[0] + (random() - .5) * object.size[0], object.position[1] + (random() - .5) * object.size[1], object.position[2] + (random() - .5) * object.size[2]];
      compare({ origin, direction: normal(subtract(target, origin)) }, triangles, tree);
    }
  }
  const triangles = nativeTriangles(temple), tree = createTriangleTree(triangles);
  assert.equal(hitTriangleTree({ origin: [2120, -160, 220], direction: [-1, 0, 0] }, tree), null, 'temple central doorway stays open after rotation');
  assert.ok(hitTriangleTree({ origin: [2120, 690, 220], direction: [-1, 0, 0] }, tree), 'surrounding temple wall remains pickable');
});

test('triangle tree reuses its built structure for a 20,000-triangle pointer-picking benchmark', t => {
  const triangles = [];
  for (let y = 0; y < 100; y++) for (let x = 0; x < 100; x++) {
    const left = x * 10, bottom = y * 10, z = (x + y) % 7;
    triangles.push([left, bottom, z], [left + 10, bottom, z], [left + 10, bottom + 10, z], [left, bottom, z], [left + 10, bottom + 10, z], [left, bottom + 10, z]);
  }
  const buildStart = performance.now(), tree = createTriangleTree(triangles), buildMs = performance.now() - buildStart;
  const random = randomGenerator(9313);
  const rays = Array.from({ length: 160 }, () => ({ origin: [random() * 1000, random() * 1000, 100], direction: [0, 0, -1] }));
  for (let i = 0; i < 15; i++) hitTriangleTree(rays[i], tree);
  const root = tree.nodes[tree.root], indices = tree.indices;
  const treeStart = performance.now(), actual = rays.map(ray => hitTriangleTree(ray, tree)), treeMs = performance.now() - treeStart;
  const bruteStart = performance.now(), expected = rays.map(ray => bruteHit(ray, triangles)), bruteMs = performance.now() - bruteStart;
  assert.deepEqual(actual, expected);
  assert.equal(tree.nodes[tree.root], root); assert.equal(tree.indices, indices);
  t.diagnostic(`20,000 triangles, 160 rays: build ${buildMs.toFixed(1)} ms; BVH ${treeMs.toFixed(2)} ms; brute ${bruteMs.toFixed(2)} ms (${(bruteMs / Math.max(treeMs, .001)).toFixed(1)}x).`);
});
