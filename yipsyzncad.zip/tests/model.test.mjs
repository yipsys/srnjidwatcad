import test from 'node:test';
import { alignObjects, distributeObjects, arrayObjects, groundObjects, spanObject } from '../dist/build-tools.js';
import assert from 'node:assert/strict';
import { TYPES, MATERIALS, PULSE_MATERIALS, createObject, createDemo, parseProject, serializeProject, duplicateObject, duplicateObjects, suggestedGroupOffset, repeatObjects, snap, History, DEFAULT_ENVIRONMENT } from '../dist/model.js';
function project(objects = [createObject('platform')]) { return { format: 'bhop-builder', version: 1, name: 'Test course', objects }; }
function rejectsMutation(mutator, pattern) {
  const value = project(); mutator(value); assert.throws(() => parseProject(JSON.stringify(value)), pattern);
}
test('every piece roundtrips through a fresh, safe project', () => {
  const value = project(Object.keys(TYPES).map(type => createObject(type, [128, -64, 16])));
  const loaded = parseProject(serializeProject(value)); assert.deepEqual(loaded, { ...value, version: 2, environment: { ...DEFAULT_ENVIRONMENT } });
  assert.notEqual(loaded.objects[0].size, value.objects[0].size);
  assert.equal(new Set(loaded.objects.map(object => object.id)).size, value.objects.length);
  assert.equal(MATERIALS.includes(loaded.objects[0].material), true);
  loaded.objects[0].size[0] = 999; assert.notEqual(value.objects[0].size[0], 999);
});
test('demo has course geometry and named start/finish pads', () => {
  const demo = parseProject(serializeProject(createDemo()));
  assert.equal(demo.name, 'First course'); assert.equal(demo.objects.length, 11);
  assert.equal(demo.objects.filter(object => object.type === 'platform').length, 10);
  assert.equal(demo.objects.some(object => object.name === 'Start pad'), true);
  assert.equal(demo.objects.some(object => object.name === 'Finish pad'), true);
  assert.equal(demo.objects.some(object => object.type === 'ramp'), true);
  assert.equal(demo.objects.every(object => object.position[2] >= object.size[2] / 2), true);
});
test('malformed, oversized and unsupported imports are rejected', () => {
  assert.throws(() => parseProject('{broken'), /valid JSON/);
  assert.throws(() => parseProject(' '.repeat(8 * 1024 * 1024 + 1)), /8 MB/);
  rejectsMutation(value => { value.version = 99; }, /format or version/);
  rejectsMutation(value => { value.objects = Array.from({ length: 2001 }, () => createObject('block')); }, /2000/);
  rejectsMutation(value => { value.name = 'x'.repeat(81); }, /80 characters/);
  rejectsMutation(value => { delete value.objects[0].visible; }, /missing or unsupported/);
  rejectsMutation(value => { value.objects[0].run = 'javascript:alert(1)'; }, /missing or unsupported/);
  rejectsMutation(value => { value.objects[0].type = 'constructor'; }, /unsupported piece/);
  rejectsMutation(value => { value.objects[0].material = 'javascript:alert(1)'; }, /unsupported material/);
  rejectsMutation(value => { value.objects[0].color = 'url(https://example.com)'; }, /hexadecimal/);
  rejectsMutation(value => { value.objects[0].collision = 1; }, /booleans/);
  rejectsMutation(value => { value.objects.push({ ...value.objects[0] }); }, /unique ID/);
});
test('prototype keys, getters and cycles cannot enter saved state', () => {
  const text = serializeProject(project());
  assert.throws(() => parseProject(text.replace('"version": 2', '"version": 2, "__proto__": {"polluted":true}')), /forbidden/);
  for (const key of ['constructor', 'prototype']) assert.throws(() => parseProject(text.replace('"position": [', `"${key}": {}, "position": [`)), /forbidden/);
  assert.equal({}.polluted, undefined);
  const value = project(); Object.defineProperty(value, 'name', { enumerable: true, get() { throw new Error('getter should never execute'); } });
  assert.throws(() => serializeProject(value), /plain data/);
  const cyclic = project(); cyclic.extra = cyclic; assert.throws(() => serializeProject(cyclic), /cycles/);
});
test('nonfinite and out-of-bounds geometry is rejected', () => {
  for (const number of [Infinity, -Infinity, NaN]) {
    const value = project(); value.objects[0].position[0] = number; assert.throws(() => serializeProject(value), /finite number/);
  }
  assert.throws(() => parseProject(serializeProject(project()).replace('"position": [\n        0', '"position": [\n        1e999')), /finite number/);
  rejectsMutation(value => { value.objects[0].position[0] = 100001; }, /finite number/);
  rejectsMutation(value => { value.objects[0].position = [0, 0]; }, /three numbers/);
  rejectsMutation(value => { value.objects[0].size[0] = 0; }, /finite number/);
  rejectsMutation(value => { value.objects[0].size[0] = 16385; }, /finite number/);
  rejectsMutation(value => { value.objects[0].rotation[0] = 360001; }, /finite number/);
  rejectsMutation(value => { value.objects[0].position[0] = '1'; }, /finite number/);
});
test('hex colors are normalized', () => {
  const value = project(); value.objects[0].color = '#AbC'; assert.equal(parseProject(JSON.stringify(value)).objects[0].color, '#aabbcc');
});
test('duplication and repetition have unique IDs, correct gaps and height', () => {
  const source = createObject('platform', [100, 200, 16]); source.size = [128, 192, 32]; source.name = 'Jump';
  const duplicate = duplicateObject(source); assert.notEqual(duplicate.id, source.id); assert.deepEqual(duplicate.position, [244, 200, 16]);
  duplicate.size[0] = 256; assert.equal(source.size[0], 128);
  const copies = repeatObjects(source, { count: 3, gap: 64, rise: 12, axis: 'y' });
  assert.deepEqual(copies.map(object => object.position), [[100, 456, 28], [100, 712, 40], [100, 968, 52]]);
  assert.equal(new Set([source.id, ...copies.map(object => object.id)]).size, 4);
  assert.throws(() => repeatObjects(source, { count: 1.5, gap: 0 }), /whole number/);
  assert.throws(() => repeatObjects(source, { count: 101, gap: 0 }), /finite number/);
  assert.throws(() => repeatObjects(source, { count: 1, gap: -1 }), /finite number/);
  assert.throws(() => repeatObjects(source, { count: 1, gap: 0, axis: 'z' }), /axis/);
  assert.throws(() => repeatObjects(source, { count: 1, gap: 0, rise: 8193 }), /finite number/);
  assert.throws(() => duplicateObject(createObject('block', [100000, 0, 0])), /Duplicate position/);
});
test('grid snapping handles positive/negative positions and invalid inputs', () => {
  assert.equal(snap(19, 16), 16); assert.equal(snap(-19, 16), -16); assert.equal(snap(25, 16), 32);
  assert.equal(Object.is(snap(-1, 16), -0), false); assert.throws(() => snap(1, 0), /positive/); assert.throws(() => snap(Infinity, 16), /finite/);
});
test('history clones snapshots, deduplicates commits and branches after undo', () => {
  const initial = project(); const history = new History(initial);
  initial.name = 'Edit A'; assert.equal(history.commit(initial), true); assert.equal(history.commit(initial), false);
  initial.name = 'Edit B'; history.commit(initial);
  const previous = history.undo(); assert.equal(previous.name, 'Edit A'); previous.name = 'Mutated returned state';
  assert.equal(history.redo().name, 'Edit B'); assert.equal(history.undo().name, 'Edit A');
  history.commit({ ...initial, name: 'Edit C' }); assert.equal(history.canRedo, false); assert.equal(history.redo(), null);
  assert.equal(history.undo().name, 'Edit A'); assert.equal(history.undo().name, 'Test course');
  assert.equal(history.canUndo, false); assert.equal(history.undo(), null);
});
test('history retains baseline and bounds storage to sixty snapshots', () => {
  const state = project(); const history = new History(state);
  for (let index = 1; index <= 90; index++) { state.name = `Revision ${index}`; history.commit(state); }
  const names = []; let previous;
  while ((previous = history.undo()) !== null) names.push(previous.name);
  assert.equal(names.length, 59); assert.equal(names[0], 'Revision 89'); assert.equal(names.at(-2), 'Revision 32'); assert.equal(names.at(-1), 'Test course');
  let redone = 0; while (history.redo() !== null) redone++; assert.equal(redone, 59);
});
test('programmatic sparse arrays cannot bypass geometric validation', () => {
  const state = project(); state.objects[0].position = Array(3);
  assert.throws(() => serializeProject(state), /finite number/);
  const sparse = project(); sparse.objects = Array(2);
  assert.throws(() => serializeProject(sparse), /must be an object/);
});
test('repeat gap accounts for rotated world-space width and depth', () => {
  const source = createObject('platform', [100, 200, 16]); source.size = [128, 192, 32];
  source.rotation = [0, 0, 90];
  const ninetyX = repeatObjects(source, { count: 2, gap: 64, axis: 'x' });
  const ninetyY = repeatObjects(source, { count: 1, gap: 64, axis: 'y' });
  assert.ok(Math.abs(ninetyX[0].position[0] - (100 + 192 + 64)) < 1e-9);
  assert.ok(Math.abs(ninetyX[1].position[0] - (100 + 2 * (192 + 64))) < 1e-9);
  assert.ok(Math.abs(ninetyY[0].position[1] - (200 + 128 + 64)) < 1e-9);
  source.rotation = [0, 0, 45];
  const worldWidth = (128 + 192) / Math.sqrt(2);
  for (const [axis, index] of [['x', 0], ['y', 1]]) {
    const copy = repeatObjects(source, { count: 1, gap: 48, axis })[0];
    const actualGap = copy.position[index] - source.position[index] - worldWidth;
    assert.ok(Math.abs(actualGap - 48) < 1e-9);
  }
  // Coupled rotations must use the same X-then-Y-then-Z order as the viewport.
  source.rotation = [90, 45, 0];
  const tilted = repeatObjects(source, { count: 1, gap: 48, axis: 'x' })[0];
  const tiltedWidth = (128 + 192) / Math.sqrt(2);
  assert.ok(Math.abs(tilted.position[0] - source.position[0] - tiltedWidth - 48) < 1e-9);
});


test('legacy version one projects migrate to independent version two environment data', () => {
  const legacy = project();
  const migrated = parseProject(JSON.stringify(legacy));
  assert.equal(migrated.version, 2);
  assert.deepEqual(migrated.environment, DEFAULT_ENVIRONMENT);
  assert.notEqual(migrated.environment, DEFAULT_ENVIRONMENT);
  assert.deepEqual(parseProject(serializeProject(legacy)), migrated);
  assert.equal(JSON.parse(serializeProject(legacy)).version, 2);
  migrated.environment.brightness = 2;
  assert.equal(parseProject(JSON.stringify(legacy)).environment.brightness, 1);
  const demo = createDemo();
  assert.equal(demo.version, 2);
  assert.deepEqual(demo.environment, { skybox: 'open-sky', rotation: 0, brightness: 1 });
  assert.deepEqual(parseProject(serializeProject(demo)), demo);
});
test('version two environment accepts only local known skyboxes and bounded controls', () => {
  const state = parseProject(JSON.stringify(project()));
  state.environment = { skybox: 'open-sky', rotation: 180, brightness: 1.5 };
  assert.deepEqual(parseProject(serializeProject(state)).environment, state.environment);
  for (const [field, value, pattern] of [
    ['skybox', 'https://example.com/sky.jpg', /unsupported skybox/],
    ['rotation', -1, /Skybox rotation/], ['rotation', 361, /Skybox rotation/],
    ['rotation', NaN, /Skybox rotation/], ['rotation', '90', /Skybox rotation/],
    ['brightness', 0.24, /Skybox brightness/], ['brightness', 2.01, /Skybox brightness/],
    ['brightness', Infinity, /Skybox brightness/],
  ]) {
    const invalid = structuredClone(state); invalid.environment[field] = value;
    assert.throws(() => serializeProject(invalid), pattern);
  }
  for (const rotation of [0, 360]) for (const brightness of [0.25, 2]) {
    state.environment = { skybox: 'none', rotation, brightness };
    assert.deepEqual(parseProject(serializeProject(state)).environment, state.environment);
  }
  const missing = structuredClone(state); delete missing.environment;
  assert.throws(() => serializeProject(missing), /missing or unsupported fields/);
  const extra = structuredClone(state); extra.environment.url = '/custom-sky.jpg';
  assert.throws(() => serializeProject(extra), /missing or unsupported fields/);
  const legacyExtra = project(); legacyExtra.environment = { ...DEFAULT_ENVIRONMENT };
  assert.throws(() => serializeProject(legacyExtra), /missing or unsupported fields/);
  const dangerous = JSON.stringify(state).replace('"skybox":"none"', '"skybox":"none","__proto__":{"polluted":true}');
  assert.throws(() => parseProject(dangerous), /forbidden property/);
});
test('environment changes participate in history and survive save reopen', () => {
  const state = parseProject(JSON.stringify(project())); const history = new History(state);
  state.environment = { skybox: 'open-sky', rotation: 45, brightness: 0.75 }; history.commit(state);
  const reopened = parseProject(serializeProject(state));
  assert.deepEqual(reopened.environment, state.environment);
  const previous = history.undo(); assert.deepEqual(previous.environment, DEFAULT_ENVIRONMENT);
  previous.environment.rotation = 300;
  assert.deepEqual(history.redo().environment, { skybox: 'open-sky', rotation: 45, brightness: 0.75 });
  assert.deepEqual(history.undo().environment, DEFAULT_ENVIRONMENT);
});

test('all pulse materials persist on block and platform projects with immutable preset IDs', () => {
  assert.deepEqual(PULSE_MATERIALS, ['pulse-cyan', 'pulse-violet', 'pulse-ember', 'pulse-rainbow']);
  assert.equal(Object.isFrozen(PULSE_MATERIALS), true);
  assert.equal(Object.isFrozen(MATERIALS), true);
  const objects = PULSE_MATERIALS.flatMap(material => ['block', 'platform'].map(type => {
    const object = createObject(type); object.material = material; return object;
  }));
  const state = parseProject(JSON.stringify(project(objects)));
  const reopened = parseProject(serializeProject(state));
  assert.deepEqual(reopened, state);
  assert.deepEqual(reopened.objects.map(object => object.material), PULSE_MATERIALS.flatMap(material => [material, material]));
  assert.equal(createObject('platform').material, 'checker');
  assert.equal(createObject('block').material, 'concrete');
});
test('animated material choices survive duplication, repetition and history navigation', () => {
  for (const material of PULSE_MATERIALS) {
    const source = createObject('block', [0, 0, 64]); source.material = material;
    assert.equal(duplicateObject(source).material, material);
    const copies = repeatObjects(source, { count: 3, gap: 64, rise: 16, axis: 'x' });
    assert.equal(copies.every(copy => copy.material === material), true);
    assert.equal(new Set([source.id, ...copies.map(copy => copy.id)]).size, 4);
  }
  const state = parseProject(JSON.stringify(project())); const history = new History(state);
  state.objects[0].material = 'pulse-rainbow'; history.commit(state);
  assert.equal(history.undo().objects[0].material, 'checker');
  const redone = history.redo(); assert.equal(redone.objects[0].material, 'pulse-rainbow');
  assert.equal(parseProject(serializeProject(redone)).objects[0].material, 'pulse-rainbow');
  assert.throws(() => parseProject(JSON.stringify({ ...redone, objects: [{ ...redone.objects[0], material: 'pulse-custom-url' }] })), /unsupported material/);
});

test('group duplication preserves relative coordinates and every editable property', () => {
  const first = createObject('platform', [-128, 64, 16]);
  first.name = 'Landing'; first.rotation = [0, 0, 45]; first.color = '#123456';
  first.material = 'pulse-cyan'; first.collision = false; first.visible = false;
  const second = createObject('block', [384, -128, 96]);
  second.name = 'Tower'; second.size = [96, 192, 160]; second.rotation = [10, 20, 30];
  second.material = 'pulse-rainbow';
  const source = [first, second], copies = duplicateObjects(source, [512, 32, 16]);
  assert.equal(new Set([...source, ...copies].map(object => object.id)).size, 4);
  assert.deepEqual(copies.map(object => object.position), [[384, 96, 32], [896, -96, 112]]);
  for (let index = 0; index < source.length; index++) {
    const { id: originalId, name: originalName, position: originalPosition, ...originalProperties } = source[index];
    const { id: copyId, name: copyName, position: copyPosition, ...copyProperties } = copies[index];
    assert.notEqual(copyId, originalId);
    assert.equal(copyName, `${originalName} Copy`);
    assert.deepEqual(copyProperties, originalProperties);
    assert.notEqual(copyProperties.size, originalProperties.size);
    assert.notEqual(copyProperties.rotation, originalProperties.rotation);
  }
  const relative = objects => objects[1].position.map((coordinate, axis) => coordinate - objects[0].position[axis]);
  assert.deepEqual(relative(copies), relative(source));
  copies[0].rotation[2] = 180; assert.equal(source[0].rotation[2], 45);
  assert.deepEqual(duplicateObjects([]), []);
  assert.deepEqual(duplicateObjects(source).map(object => object.position), source.map(object => object.position));
});
test('group paste spacing includes each rotated width and the distance between pieces', () => {
  const first = createObject('platform', [-100, 0, 16]); first.size = [128, 192, 32]; first.rotation = [0, 0, 90];
  const second = createObject('block', [300, 100, 64]); second.size = [128, 128, 128]; second.rotation = [0, 0, 45];
  const minimum = -100 - 192 / 2;
  const maximum = 300 + (128 * Math.sqrt(2)) / 2;
  const offset = suggestedGroupOffset([first, second], 48);
  assert.ok(Math.abs(offset[0] - (maximum - minimum + 48)) < 1e-9);
  assert.deepEqual(offset.slice(1), [0, 0]);
  const copies = duplicateObjects([first, second], offset);
  const pastedMinimum = copies[0].position[0] - 192 / 2;
  assert.ok(Math.abs(pastedMinimum - maximum - 48) < 1e-9);
  assert.deepEqual(suggestedGroupOffset([], 48), [0, 0, 0]);
  assert.throws(() => suggestedGroupOffset([first], -1), /Group gap/);
  assert.throws(() => suggestedGroupOffset([first], Infinity), /Group gap/);
});
test('invalid group copies fail without mutating the originals', () => {
  const first = createObject('block', [0, 0, 64]);
  const edge = createObject('block', [100000, 0, 64]);
  const original = structuredClone([first, edge]);
  assert.throws(() => duplicateObjects([first, edge], [128, 0, 0]), /Duplicate position/);
  assert.deepEqual([first, edge], original);
  assert.throws(() => duplicateObjects([first, { ...edge, id: first.id }]), /unique ID/);
  assert.throws(() => duplicateObjects([first], [0, NaN, 0]), /Group duplicate offset/);
});


test('align tools use rotated envelope edges and preserve the last selected primary', () => {
  const first = createObject('platform', [0, 100, 32]); first.size = [128, 192, 32]; first.rotation = [0, 0, 90];
  const primary = createObject('block', [400, 200, 128]); primary.size = [100, 128, 64];
  for (const [mode, expected] of [['min', 446], ['center', 400], ['max', 354]]) {
    const aligned = alignObjects([first, primary], { axis: 'x', mode });
    assert.ok(Math.abs(aligned[0].position[0] - expected) < 1e-9);
    assert.deepEqual(aligned[1], primary);
    assert.equal(aligned[0].id, first.id);
    assert.deepEqual(aligned[0].position.slice(1), first.position.slice(1));
  }
  assert.deepEqual(first.position, [0, 100, 32]);
  assert.throws(() => alignObjects([first], { axis: 'u' }), /Axis/);
  assert.throws(() => alignObjects([first], { mode: 'nearest' }), /Alignment mode/);
});
test('distribution creates equal clear gaps and keeps extreme objects fixed', () => {
  const first = createObject('block', [0, 0, 64]); first.size = [128, 128, 128];
  const middle = createObject('platform', [200, 100, 16]); middle.size = [128, 192, 32]; middle.rotation = [0, 0, 90];
  const last = createObject('block', [900, 200, 64]); last.size = [256, 128, 128];
  const distributed = distributeObjects([last, first, middle], { axis: 'x' });
  assert.deepEqual(distributed.map(object => object.id), [first.id, middle.id, last.id]);
  assert.deepEqual(distributed[0], first); assert.deepEqual(distributed[2], last);
  assert.ok(Math.abs(distributed[1].position[0] - 418) < 1e-9);
  assert.ok(Math.abs(distributed[1].position[0] - 96 - 64 - 258) < 1e-9);
  assert.ok(Math.abs(772 - distributed[1].position[0] - 96 - 258) < 1e-9);
  assert.deepEqual(distributed[1].position.slice(1), [100, 16]);
  assert.equal(middle.position[0], 200);
  assert.throws(() => distributeObjects([first, last], { axis: 'x' }), /three objects/);
  assert.throws(() => distributeObjects([0, 10, 20].map(x => createObject('block', [x, 0, 64]))), /not enough space/);
});
test('array tool repeats group layout with rotated bounds and column rise', () => {
  const first = createObject('platform', [0, 0, 16]); first.size = [128, 192, 32]; first.rotation = [0, 0, 90]; first.material = 'pulse-cyan';
  const second = createObject('block', [320, 100, 64]); second.size = [64, 128, 64];
  const copies = arrayObjects([first, second], { columns: 3, rows: 2, gapX: 32, gapY: 16, rise: 20 });
  assert.equal(copies.length, 10);
  assert.equal(new Set([first, second, ...copies].map(object => object.id)).size, 12);
  const expectedOffsets = [[480, 0, 20], [960, 0, 40], [0, 244, 0], [480, 244, 20], [960, 244, 40]];
  for (let cell = 0; cell < expectedOffsets.length; cell++) {
    const pair = copies.slice(cell * 2, cell * 2 + 2);
    for (let index = 0; index < 2; index++) {
      const source = [first, second][index];
      for (let axis = 0; axis < 3; axis++) assert.ok(Math.abs(pair[index].position[axis] - source.position[axis] - expectedOffsets[cell][axis]) < 1e-9);
      assert.equal(pair[index].material, source.material);
      assert.deepEqual(pair[index].rotation, source.rotation);
    }
  }
  assert.deepEqual(arrayObjects([first], { columns: 1, rows: 1 }), []);
  assert.throws(() => arrayObjects([first], { columns: 1.5 }), /whole numbers/);
  assert.throws(() => arrayObjects([first], { rows: 21 }), /Rows/);
  assert.throws(() => arrayObjects([first], { gapX: -1 }), /X gap/);
  assert.throws(() => arrayObjects(Array.from({ length: 6 }, () => createObject('block')), { columns: 20, rows: 20 }), /2,000 objects/);
  assert.throws(() => arrayObjects([createObject('block', [100000, 0, 64])], { columns: 2 }), /Duplicate position/);
});
test('grounding uses the rotated vertical envelope without changing appearance', () => {
  const object = createObject('platform', [100, 200, 500]); object.size = [128, 192, 32]; object.rotation = [90, 0, 0];
  const grounded = groundObjects([object], { height: 48 })[0];
  assert.ok(Math.abs(grounded.position[2] - 144) < 1e-9);
  assert.deepEqual(grounded.position.slice(0, 2), [100, 200]);
  assert.equal(grounded.id, object.id); assert.deepEqual(grounded.rotation, object.rotation);
  assert.equal(object.position[2], 500);
  assert.throws(() => groundObjects([object], { height: 100000 }), /position/);
});
test('span tools join XY endpoints with local Y length and explicit bottom elevation', () => {
  for (const type of ['wall', 'bridge']) {
    const object = spanObject(type, [0, 0, 999], [300, 400, -999], { width: 32, height: 64, elevation: 48, material: 'pulse-violet', color: '#ABC', collision: false });
    assert.deepEqual(object.size, [32, 500, 64]); assert.deepEqual(object.position, [150, 200, 80]);
    assert.equal(object.material, 'pulse-violet'); assert.equal(object.color, '#aabbcc'); assert.equal(object.collision, false);
    const angle = object.rotation[2] * Math.PI / 180;
    const endpoint = side => [object.position[0] - side * Math.sin(angle) * 250, object.position[1] + side * Math.cos(angle) * 250];
    for (const [actual, expected] of [[endpoint(-1), [0, 0]], [endpoint(1), [300, 400]]]) {
      for (let axis = 0; axis < 2; axis++) assert.ok(Math.abs(actual[axis] - expected[axis]) < 1e-9);
    }
  }
  assert.equal(spanObject('wall', [0, 0, 0], [0, 16384, 0]).size[1], 16384);
  assert.throws(() => spanObject('wall', [0, 0, 0], [0, 0, 0]), /Span length/);
  assert.throws(() => spanObject('wall', [0, 0, 0], [0, 16385, 0]), /Span length/);
  assert.throws(() => spanObject('ramp', [0, 0, 0], [100, 0, 0]), /wall or bridge/);
  assert.throws(() => spanObject('wall', [0, 0, 0], [100, 0, 0], { elevation: 100000 }), /position/);
});
test('building tool results remain editable after save and history navigation', () => {
  const state = parseProject(JSON.stringify(project([createObject('block', [0, 0, 64]), createObject('block', [500, 0, 64])])));
  const history = new History(state);
  const aligned = alignObjects(state.objects, { axis: 'y', mode: 'min' });
  state.objects = groundedAndSpanned(aligned);
  history.commit(state);
  assert.deepEqual(parseProject(serializeProject(state)), state);
  assert.equal(history.undo().objects.length, 2);
  const restored = history.redo(); assert.equal(restored.objects.length, 3);
  assert.deepEqual(restored, state);
  function groundedAndSpanned(objects) {
    return [...groundObjects(objects, { height: 32 }), spanObject('bridge', [0, 0, 0], [500, 0, 0], { width: 128, height: 32, elevation: 160 })];
  }
});
test('span defaults match the canonical wall and bridge widths and heights', () => {
  const bridge = spanObject('bridge', [0, 0, 0], [0, 512, 0]);
  assert.deepEqual(bridge.size, [TYPES.bridge.size[0], 512, TYPES.bridge.size[2]]);
  const wall = spanObject('wall', [0, 0, 0], [0, 256, 0]);
  assert.deepEqual(wall.size, [TYPES.wall.size[0], 256, TYPES.wall.size[2]]);
});
test('new structural assets retain geometry and appearance through copies, arrays and history', () => {
  const newTypes = ['arch', 'doorway', 'beam', 'fence', 'crate', 'corner'];
  assert.equal(newTypes.every(type => Object.hasOwn(TYPES, type)), true);
  const originals = newTypes.map((type, index) => {
    const object = createObject(type, [index * 512, index * 128, TYPES[type].size[2] / 2]);
    object.rotation = [0, 0, index * 15];
    return object;
  });
  const state = parseProject(JSON.stringify(project(originals)));
  const history = new History(state);
  const copies = duplicateObjects(state.objects, [0, -1024, 64]);
  for (let index = 0; index < originals.length; index++) {
    const source = originals[index], copy = copies[index];
    assert.equal(copy.type, source.type);
    assert.deepEqual(copy.size, source.size);
    assert.deepEqual(copy.rotation, source.rotation);
    assert.equal(copy.color, source.color);
    assert.equal(copy.material, source.material);
    assert.notEqual(copy.id, source.id);
  }
  const gridCopies = arrayObjects(state.objects, { columns: 2, rows: 2, gapX: 64, gapY: 64, rise: 32 });
  assert.equal(gridCopies.length, 18);
  state.objects.push(...gridCopies);
  history.commit(state);
  const reopened = parseProject(serializeProject(state));
  assert.deepEqual(reopened, state);
  assert.equal(new Set(reopened.objects.map(object => object.id)).size, 24);
  for (const type of newTypes) assert.equal(reopened.objects.filter(object => object.type === type).length, 4);
  assert.equal(history.undo().objects.length, 6);
  assert.deepEqual(history.redo(), reopened);
});

test('industrial, nature and street assets preserve editable data in files, group copies and arrays', () => {
  const assetTypes = ['container', 'barrel', 'truss', 'gate', 'pipewall', 'jumppad', 'boostramp', 'rock', 'tree', 'pine', 'sign', 'lamp'];
  assert.equal(assetTypes.every(type => Object.hasOwn(TYPES, type)), true);
  const objects = assetTypes.map((type, index) => {
    const object = createObject(type, [index * 640, (index % 3) * 512, TYPES[type].size[2] / 2]);
    object.rotation = [0, index % 2 ? 15 : 0, index * 15];
    if (['tree', 'pine', 'gate', 'jumppad', 'boostramp'].includes(type)) object.collision = false;
    return object;
  });
  const state = parseProject(JSON.stringify(project(objects)));
  const history = new History(state);
  const copies = duplicateObjects(state.objects, [0, -2048, 64]);
  assert.equal(new Set([...state.objects, ...copies].map(object => object.id)).size, 24);
  for (let index = 0; index < objects.length; index++) {
    const source = objects[index], copy = copies[index];
    assert.equal(copy.type, source.type); assert.deepEqual(copy.size, source.size);
    assert.deepEqual(copy.rotation, source.rotation); assert.equal(copy.material, source.material);
    assert.equal(copy.color, source.color); assert.equal(copy.collision, source.collision);
    assert.equal(copy.visible, source.visible);
  }
  const grid = arrayObjects(state.objects, { columns: 2, rows: 2, gapX: 128, gapY: 128, rise: 32 });
  assert.equal(grid.length, 36);
  state.objects.push(...grid); history.commit(state);
  const loaded = parseProject(serializeProject(state)); assert.deepEqual(loaded, state);
  assert.equal(new Set(loaded.objects.map(object => object.id)).size, 48);
  for (const type of assetTypes) {
    const instances = loaded.objects.filter(object => object.type === type);
    assert.equal(instances.length, 4);
    assert.equal(instances.every(object => object.collision === objects.find(source => source.type === type).collision), true);
  }
  assert.equal(history.undo().objects.length, 12);
  assert.deepEqual(history.redo(), loaded);
  assert.equal(createObject('tree').collision, true);
});

test('graveyard and aged prop assets persist through group copying and history', () => {
  const assetTypes = ['headstone', 'cross', 'grave', 'tomb', 'coffin', 'crypt', 'cemeterygate', 'cemeteryfence', 'brokenwall', 'deadtree', 'skull', 'bones', 'lantern', 'skullpile', 'generator', 'radio', 'planks', 'chain', 'sandbags', 'bench', 'wheel', 'trafficcone', 'dumpster', 'pallet'];
  assert.equal(Object.keys(TYPES).length, 117);
  const objects = assetTypes.map((type, index) => {
    const object = createObject(type, [index * 480, (index % 4) * 384, TYPES[type].size[2] / 2]);
    object.rotation = [0, index % 2 ? 10 : 0, index * 5];
    object.collision = index % 3 !== 0;
    return object;
  });
  const state = parseProject(JSON.stringify(project(objects)));
  const history = new History(state);
  const copies = duplicateObjects(state.objects, [0, -2048, 64]);
  for (let index = 0; index < objects.length; index++) {
    const source = objects[index], copy = copies[index];
    assert.equal(copy.type, source.type); assert.deepEqual(copy.size, source.size);
    assert.deepEqual(copy.rotation, source.rotation); assert.equal(copy.material, source.material);
    assert.equal(copy.color, source.color); assert.equal(copy.collision, source.collision);
    assert.notEqual(copy.id, source.id);
  }
  state.objects.push(...copies); state.objects[0].material = 'rust'; history.commit(state);
  const reopened = parseProject(serializeProject(state)); assert.deepEqual(reopened, state);
  assert.equal(new Set(reopened.objects.map(object => object.id)).size, 48);
  for (const type of assetTypes) assert.equal(reopened.objects.filter(object => object.type === type).length, 2);
  const previous = history.undo(); assert.equal(previous.objects.length, 24);
  assert.equal(previous.objects[0].material, 'weathered');
  assert.deepEqual(history.redo(), reopened);
  assert.equal(createObject('deadtree').collision, true);
});
test('rust and weathered remain known materials on existing pieces without schema changes', () => {
  for (const material of ['rust', 'weathered']) {
    assert.equal(MATERIALS.includes(material), true);
    const object = createObject('block'); object.material = material;
    const state = parseProject(serializeProject(project([object])));
    assert.equal(state.version, 2); assert.equal(state.objects[0].material, material);
    assert.equal(duplicateObject(state.objects[0]).material, material);
    assert.equal(repeatObjects(state.objects[0], { count: 2, gap: 64 }).every(copy => copy.material === material), true);
  }
});
