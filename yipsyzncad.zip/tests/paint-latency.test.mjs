import test from 'node:test';
import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import { TYPES, createObject } from '../dist/model.js';
import { EditorViewport } from '../dist/viewport.js';
import { makePaintPoint } from '../dist/paint.js';
function fixture(objects) {
  const viewport = Object.create(EditorViewport.prototype), uploads = [], writes = [], deleted = [];
  let bufferId = 0, builds = 0;
  Object.assign(viewport, {
    objects, meshes:[], selectedIds:[], selectedId:null, mode:'select', callbacks:{},
    _meshCache:new Map(),_geometryDirty:true,_selectedDirty:true,_sceneBuffersDirty:true,_paintDirty:true,
    paintBrush:{color:'#ff4bb8',size:24},worldPerPixel:1,
    canvas:{style:{},getBoundingClientRect:()=>({left:0,top:0}),setPointerCapture(){},hasPointerCapture:()=>false},
    gl:{ARRAY_BUFFER:1,DYNAMIC_DRAW:2,createBuffer:()=>({id:++bufferId}),bindBuffer(){},
      bufferData(_target,bytes){writes.push({kind:'allocate',bytes});},
      bufferSubData(_target,offset,data){writes.push({kind:'append',offset,bytes:data.byteLength});},
      deleteBuffer(buffer){deleted.push(buffer);}},
    _upload(name,data){uploads.push({name,length:data.length});},_scheduleFrame(){},_updateCamera(){},
    _objectData(object){builds++;return EditorViewport.prototype._objectData.call(this,object);},
    _render(){if(this._geometryDirty)this._buildScene();if(this._selectedDirty)this._buildSelection();if(this._paintDirty)this._buildPaint();},
  });
  return {viewport,uploads,writes,deleted,get builds(){return builds;}};
}
function surfacePoint(x=0,start=true) {
  return {position:[x,0,.5],normal:[0,0,1],start};
}
test('100-asset drawing never rebuilds base meshes at press, move or release', t => {
  const objects=Object.keys(TYPES).slice(0,97).map((type,i)=>createObject(type,[(i%10)*4096,Math.floor(i/10)*4096,0]));
  objects.push(...Array.from({length:3},()=>createObject('block')));
  const f=fixture(objects),v=f.viewport,ramp=objects.find(o=>o.type==='surf');
  v._buildScene();const baseline=f.builds;
  v.setSelected([ramp.id]);v.setMode('paint');v._render();
  const warm=f.builds;assert.equal(warm,baseline);
  v._hit=(x,y)=>({object:ramp,point:[x,y,8+x],localPoint:[x,y,8+x],localNormal:[-Math.SQRT1_2,0,Math.SQRT1_2],normal:[-Math.SQRT1_2,0,Math.SQRT1_2]});
  // The real renderer is exercised separately in browser QA; here submit using
  // the native buffer-building path with no browser-global paint scheduling.
  const savedGl=v.gl;v.gl=null;
  const begin=performance.now();v._beginPaint({clientX:-40,clientY:0,pointerId:1});v.gl=savedGl;v._render();
  const first=performance.now()-begin;
  const move=performance.now();v._paintMove({clientX:40,clientY:0,pointerId:1},v.drag);v._render();
  const moved=performance.now()-move;
  const release=performance.now();v._pointerUp({pointerId:1,type:'pointerup'});v._render();
  const ended=performance.now()-release;
  assert.equal(f.builds,baseline,'no asset mesh regenerates during drawing');
  assert.ok(ramp.paint[0].points.length>10);
  t.diagnostic('100 assets: first dab '+first.toFixed(2)+' ms; move '+moved.toFixed(2)+' ms; release '+ended.toFixed(2)+' ms; zero base-mesh rebuilds');
});
test('selection and paint-only cloned scenes preserve geometry while transforms rebuild one asset', () => {
  const objects=[createObject('surf'),createObject('block'),createObject('egypttemple')],f=fixture(objects),v=f.viewport;
  v._buildScene();const base=f.builds,faces=v.meshes[0].localFaces;
  f.uploads.length=0;v.setSelected([objects[0].id]);v._render();
  assert.equal(f.builds,base);assert.deepEqual(f.uploads.map(u=>u.name),['selected']);
  const copies=structuredClone(objects);copies[0].name='Renamed';copies[0].paint=[{color:'#ff4bb8',size:24/1024,points:[surfacePoint()]}];
  f.uploads.length=0;v.setScene(copies);v._render();
  assert.equal(f.builds,base);assert.equal(v.meshes[0].localFaces,faces);assert.equal(v.meshes[0].object,copies[0]);
  assert.ok(!f.uploads.some(u=>u.name==='solid'||u.name==='edges'));
  copies[1].position[0]=256;v.setScene(copies);v._render();
  assert.equal(f.builds,base+1);assert.equal(v.meshes[0].localFaces,faces);
});
test('drawing appends only new GPU paint vertices after a thousand saved points', () => {
  const ramp=createObject('surf'),f=fixture([ramp]),v=f.viewport,points=[];
  for(let i=0;i<1000;i++) points.push(makePaintPoint(ramp,[(i%11-5)*12,Math.floor(i/11)*2-80,8+(i%11-5)*12],[-Math.SQRT1_2,0,Math.SQRT1_2],i===0));
  ramp.paint=[{color:'#ff4bb8',size:20/1024,points}];v._buildScene();v._buildPaint();
  const totalBytes=v.meshes[0].paintVertexCount*14*4;f.writes.length=0;
  points.push(makePaintPoint(ramp,[48,100,56],[-Math.SQRT1_2,0,Math.SQRT1_2],false));v.invalidatePaint();v._buildPaint();
  const appended=f.writes.filter(w=>w.kind==='append');
  assert.equal(f.writes.filter(w=>w.kind==='allocate').length,0);
  assert.equal(appended.length,1);assert.ok(appended[0].offset>0);
  assert.ok(appended[0].bytes<totalBytes/10,'new upload excludes saved strokes');
});
test('clearing paint resets vertex counts without regenerating the asset', () => {
  const block=createObject('block'),f=fixture([block]),v=f.viewport;
  block.paint=[{color:'#35dcea',size:.2,points:[surfacePoint()]}];v._buildScene();v._buildPaint();
  assert.ok(v.paintCount>0);const baseline=f.builds;
  delete block.paint;v.invalidatePaint();v._buildPaint();
  assert.equal(v.paintCount,0);assert.equal(v.meshes[0].paintVertexCount,0);assert.equal(f.builds,baseline);
});
