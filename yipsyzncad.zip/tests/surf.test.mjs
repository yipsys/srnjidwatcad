import test from 'node:test';
import assert from 'node:assert/strict';
import {createObject, parseProject, serializeProject, duplicateObject, suggestedGroupOffset, worldAxisSize, History} from '../dist/model.js';
import {surfSections, surfBoundsSize, surfSlope, reshapeSurf, maxSurfBend} from '../dist/surf.js';
import {makeGeometry, EditorViewport} from '../dist/viewport.js';
const project = objects => ({format:'bhop-builder',version:2,name:'Surf course',environment:{skybox:'none',rotation:0,brightness:1},objects});
const near = (a,b,epsilon=1e-6) => assert.ok(Math.abs(a-b)<epsilon, a+' ~= '+b);
test('surf shape persists independently through projects, copies and history',()=>{
 const ramp=createObject('surf'); Object.assign(ramp,reshapeSurf(ramp,{bend:90,slope:50,side:-1}));
 const copy=duplicateObject(ramp); assert.deepEqual(copy.surf,ramp.surf); assert.notEqual(copy.surf,ramp.surf);
 const loaded=parseProject(serializeProject(project([ramp,copy]))); assert.deepEqual(loaded.objects[0],ramp);
 const history=new History(project([ramp])); const edited=structuredClone(ramp); Object.assign(edited,reshapeSurf(edited,{length:2048,bend:-75}));history.commit(project([edited]));assert.equal(history.undo().objects[0].surf.bend,90);assert.equal(history.redo().objects[0].size[1],2048);
});
test('surf validation rejects invalid or misplaced shape data without relaxing legacy schema',()=>{
 for(const mutate of [o=>delete o.surf,o=>o.surf.bend=NaN,o=>o.surf.thickness=0,o=>o.surf.side=0,o=>o.surf.extra='x',o=>{o.size[1]=1;o.surf.bend=150;}]) {const r=createObject('surf');mutate(r);assert.throws(()=>serializeProject(project([r])));}
 const ordinary=createObject('block');ordinary.surf={bend:0,thickness:1,side:1};assert.throws(()=>serializeProject(project([ordinary])));
 const legacy={format:'bhop-builder',version:1,name:'Legacy',objects:[createObject('block')]};assert.equal(parseProject(JSON.stringify(legacy)).version,2);
});
test('straight and bent surf ramps have a closed upward riding surface and ground-aligned bottom',()=>{
 for(const bend of [-150,-65,0,65,150]){const r=createObject('surf');Object.assign(r,reshapeSurf(r,{bend}));const sections=surfSections(r), bounds=surfBoundsSize(r);const mesh=makeGeometry(r); assert.ok(mesh.faces.length>4);assert.ok(mesh.faces.some(f=>f.normal[2]>.3));const all=mesh.faces.flatMap(f=>f.points);near(Math.min(...all.map(p=>p[2])),-r.size[2]/2);near(Math.max(...all.map(p=>p[2])),r.size[2]/2);near(Math.max(...all.map(p=>p[0])),-Math.min(...all.map(p=>p[0])));assert.ok(bounds.every(n=>Number.isFinite(n)&&n>0));
 for(const s of sections){near(Math.hypot(s.points[1][0]-s.points[0][0],s.points[1][1]-s.points[0][1]),r.size[0]);}
 const vp=Object.create(EditorViewport.prototype);const data=vp._objectData(r);assert.equal(data.vertices.length%14,0);assert.ok(data.vertices.every(Number.isFinite));
 }
 const r=createObject('surf');const a=surfSections(r)[0];near(a.points[1][2]-a.points[0][2],256);Object.assign(r,reshapeSurf(r,{side:-1}));assert.ok(surfSections(r)[0].points[1][2]<surfSections(r)[0].points[0][2]);
});
test('width edits preserve slope and short ramps clamp bends before self intersection',()=>{
 const r=createObject('surf');Object.assign(r,reshapeSurf(r,{width:512}));near(surfSlope(r),45);near(r.size[2],528);Object.assign(r,reshapeSurf(r,{length:128,bend:150}));near(r.surf.bend,maxSurfBend(512,128));assert.doesNotThrow(()=>serializeProject(project([r])));assert.throws(()=>reshapeSurf(r,{slope:90}));assert.throws(()=>reshapeSurf(r,{width:16384,slope:80}));
});
test('group copy spacing follows the bent footprint instead of the cross-section width',()=>{
 const r=createObject('surf');Object.assign(r,reshapeSurf(r,{bend:100}));const bounds=surfBoundsSize(r);assert.ok(bounds[0]>r.size[0]);near(worldAxisSize(r,0),bounds[0]);near(suggestedGroupOffset([r],32)[0],bounds[0]+32);
});
test('surf handle drags change geometry with one transaction and can cancel',()=>{
 const r=createObject('surf'), vp=Object.create(EditorViewport.prototype); let ends=0, transforms=0;vp.objects=[r];vp.width=500;vp.height=500;vp.snapEnabled=true;vp.snapStep=32;vp.callbacks={onTransform:()=>transforms++,onTransformEnd:()=>ends++};vp.invalidate=()=>{};vp._updateCursor=()=>{};vp.canvas={hasPointerCapture:()=>false};
 const identity=new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]);
 const drag={kind:'surf',pointer:1,object:r,field:'length',startX:0,startY:0,grip:{world:[0,0,0]},base:structuredClone(r),matrix:identity,scalePerPixel:1};vp.drag=drag;vp._surfMove({clientX:0,clientY:-10000,pointerId:1},drag);assert.ok(r.size[1]>1024);assert.equal(ends,0);vp._pointerUp({pointerId:1});assert.equal(ends,1);assert.ok(transforms>0);
 const before=structuredClone(r);vp.drag={...drag,field:'bend',base:before};vp._surfMove({clientX:10000,clientY:0,pointerId:1},vp.drag);assert.notEqual(r.surf.bend,before.surf.bend);vp._pointerUp({cancel:true});assert.deepEqual(r.surf,before.surf);assert.equal(ends,2);
});

test('native picking follows the sloped curved surface and its empty footprint',()=>{
 const r=createObject('surf'); Object.assign(r,reshapeSurf(r,{bend:100})); const vp=Object.create(EditorViewport.prototype), data=vp._objectData(r); vp.meshes=[{object:r,triangles:data.triangles}]; vp._geometryDirty=false;vp._updateCamera=()=>{};
 const section=surfSections(r)[Math.floor(surfSections(r).length/2)];
 vp._ray=()=>({origin:[section.center[0],section.center[1],1000],direction:[0,0,-1]});assert.equal(vp._hit(0,0)?.object,r);
 vp._ray=()=>({origin:[data.min[0]-30,data.max[1]+30,1000],direction:[0,0,-1]});assert.equal(vp._hit(0,0),null);
});

test('width and slope shaping preserve the bottom plane rather than burying a ramp',()=>{
 const r=createObject('surf',[0,0,136]);Object.assign(r,reshapeSurf(r,{width:512,slope:50}));near(r.position[2]-r.size[2]/2,0);
 const turned=createObject('surf',[10,20,30]);turned.rotation=[25,40,70];const oldPos=[...turned.position];const oldHeight=turned.size[2];const next=reshapeSurf(turned,{slope:60});const lift=(next.size[2]-oldHeight)/2;near(Math.hypot(...next.position.map((n,i)=>n-oldPos[i])),lift);
});
