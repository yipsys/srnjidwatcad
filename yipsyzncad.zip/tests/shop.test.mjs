import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, access } from 'node:fs/promises';
import { SHOP_ASSETS, SHOP_PACK } from '../dist/shop-assets.js';
import { TYPES, createObject, createDemo, duplicateObjects, History, serializeProject, parseProject } from '../dist/model.js';
import { makeGeometry, EditorViewport } from '../dist/viewport.js';
const shopTypes=Object.keys(SHOP_ASSETS);
function pick(type,origin,direction){
 const viewport=Object.create(EditorViewport.prototype),piece=createObject(type);
 viewport.meshes=[{object:piece,triangles:viewport._objectData(piece).triangles}];
 viewport._geometryDirty=false;viewport._updateCamera=()=>{};viewport._ray=()=>({origin,direction});
 return viewport._hit(0,0);
}
test('shop interior exposes stocked shelves and exactly nine other furnishings',async()=>{
 assert.equal(shopTypes.length,10);assert.equal(new Set(SHOP_PACK.types).size,10);assert.deepEqual(SHOP_PACK.types,shopTypes);
 assert.equal(SHOP_PACK.positions.length,10);assert.ok(shopTypes.includes('shopshelf'));
 const html=await readFile(new URL('../dist/index.html',import.meta.url),'utf8');
 assert.ok(html.includes('value="shop-interior"'));assert.ok(html.includes('value="shop"'));
 for(const type of shopTypes){
  assert.ok(Object.hasOwn(TYPES,type));assert.equal(TYPES[type].category,'shop');
  assert.equal(html.split('data-piece="'+type+'"').length-1,1);
  await access(new URL('../dist/assets/thumbnails/'+type+'.svg',import.meta.url));
 }
});
test('all ten shop fittings preserve dimensions, appearance and group layout in files and history',()=>{
 const state=createDemo();
 const pieces=shopTypes.map((type,i)=>{const piece=createObject(type,[i*320,512,TYPES[type].size[2]/2]);piece.size=piece.size.map(v=>v*1.2);piece.rotation=[0,0,i*15];piece.color='#a9bdcb';piece.material=i%2?'metal':'concrete';return piece;});
 state.objects.push(...pieces);const history=new History(state);
 const changed=structuredClone(state);const copies=duplicateObjects(pieces,[0,1024,64]);changed.objects.push(...copies);history.commit(changed);
 assert.deepEqual(parseProject(serializeProject(changed)),changed);assert.deepEqual(history.undo(),state);assert.deepEqual(history.redo(),changed);
 copies.forEach((p,i)=>{assert.notEqual(p.id,pieces[i].id);assert.deepEqual(p.size,pieces[i].size);assert.deepEqual(p.rotation,pieces[i].rotation);});
});
test('shop meshes use practical geometry budgets and stock uses original fixed package colours',()=>{
 for(const type of shopTypes){
  const geometry=makeGeometry(createObject(type));assert.ok(geometry.faces.length>24,type+' has real detail');assert.ok(geometry.faces.length<=2500,type+' triangle budget');
  assert.ok(geometry.faces.some(f=>!f.color),type+' recolorable furniture');
 }
 for(const type of ['shopshelf','snackrack','drinksfridge','slushiemachine']){
  const colors=new Set(makeGeometry(createObject(type)).faces.map(f=>f.color).filter(Boolean));
  assert.ok(colors.size>=5,type+' stocked colour detail');
 }
});
test('shop shelf decks are pickable while clear spaces between shelves and rack wire remain open',()=>{
 const [sx,sy,sz]=TYPES.shopshelf.size;
 assert.equal(pick('shopshelf',[-.7*sx,-.40*sy,-.22*sz],[1,0,0]),null);
 assert.ok(pick('shopshelf',[.40*sx,-.40*sy,sz],[0,0,-1]));
 const rack=TYPES.snackrack.size;
 assert.equal(pick('snackrack',[-.7*rack[0],0,-.095*rack[2]],[1,0,0]),null);
});
test('stacked shopping baskets retain a recessed interior and real wall slots',()=>{
 const [sx,sy,sz]=TYPES.shoppingbaskets.size;
 const center=pick('shoppingbaskets',[0,0,sz],[0,0,-1]);
 assert.ok(center);assert.ok(center.point[2]<0,'center reaches the recessed floor');
 assert.equal(pick('shoppingbaskets',[0,-.7*sy,.15*sz],[0,1,0]),null);
});

test('store bin has a real rim and deep liner rather than a filled top',()=>{
 const [sx,sy,sz]=TYPES.shopbin.size;
 const center=pick('shopbin',[0,0,sz],[0,0,-1]),rim=pick('shopbin',[.38*sx,0,sz],[0,0,-1]);
 assert.ok(center&&rim);assert.ok(center.point[2]<-.3*sz);assert.ok(rim.point[2]>.4*sz);
});

test('drinks remain exposed in the fridge and freezer stock sits in a recessed well',()=>{
 const [sx,sy,sz]=TYPES.drinksfridge.size;
 const stock=pick('drinksfridge',[-.281*sx,-sy,-.246*sz],[0,1,0]);
 const gap=pick('drinksfridge',[-.332*sx,-sy,-.248*sz],[0,1,0]);
 assert.ok(stock&&gap);assert.ok(gap.point[1]>stock.point[1]+.4*sy,'clear framed front keeps stock visible');
 const [fx,fy,fz]=TYPES.chestfreezer.size;
 const pack=pick('chestfreezer',[-.33*fx,-.20*fy,fz],[0,0,-1]);
 const floor=pick('chestfreezer',[-.22*fx,-.20*fy,fz],[0,0,-1]);
 assert.ok(pack&&floor);assert.ok(floor.point[2]<pack.point[2]-.2*fz,'packs occupy a real recessed freezer well');
});
