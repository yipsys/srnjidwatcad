import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { performance } from 'node:perf_hooks';
import { createObject, History } from '../dist/model.js';
import { reshapeSurf } from '../dist/surf.js';
import { EditorViewport } from '../dist/viewport.js';

const project = objects => ({ format:'bhop-builder',version:2,name:'Selection regression',environment:{skybox:'none',rotation:0,brightness:1},objects });
const projection = new Float32Array([.001,0,0,0,0,.001,0,0,0,0,.001,0,0,0,0,1]);
const event = (clientX=100,clientY=100,extra={}) => ({clientX,clientY,pointerId:1,button:0,type:'pointerdown',preventDefault(){},...extra});
function fixture(objects) {
  const viewport=Object.create(EditorViewport.prototype),writes=[],deleted=[],uploads=[];
  let serial=0,bound=null,builds=0;
  const gl={ARRAY_BUFFER:1,DYNAMIC_DRAW:2,
    createBuffer:()=>({id:++serial}),bindBuffer(_target,buffer){bound=buffer;},
    bufferData(_target,data){writes.push({buffer:bound,bytes:typeof data==='number'?data:data.byteLength});},
    bufferSubData(_target,offset,data){writes.push({buffer:bound,offset,bytes:data.byteLength});},
    deleteBuffer(buffer){if(buffer)deleted.push(buffer);},deleteProgram(){},deleteTexture(){}};
  const buffers=Object.fromEntries(['solid','edges','selected','grid','ground','ghost','paint'].map(name=>[name,{name}]));
  Object.assign(viewport,{objects,meshes:[],selectedIds:[],selectedId:null,mode:'translate',callbacks:{},
    _meshCache:new Map(),_geometryDirty:true,_selectedDirty:true,_sceneBuffersDirty:true,_paintDirty:true,
    _destroyed:false,_frame:0,_events:[],_skyLoadToken:0,resizeObserver:{disconnect(){}},
    width:1000,height:600,worldPerPixel:1,matrix:projection.slice(),inverseMatrix:projection.slice(),
    view:'perspective',snapEnabled:true,snapStep:32,axisHandles:[],surfHandles:[],drag:null,
    camera:{target:[0,0,0],distance:1000,azimuth:0,elevation:.7},right:[1,0,0],up:[0,0,1],
    canvas:{style:{},focus(){},getBoundingClientRect:()=>({left:0,top:0}),setPointerCapture(){},hasPointerCapture:()=>false,remove(){}},overlay:{remove(){}},
    gl,buffers,_scheduleFrame(){},_updateCamera(){},_ray:()=>null,_planePoint:()=>null,
    _upload(name,data){uploads.push({name,length:data.length});EditorViewport.prototype._upload.call(this,name,data);},
    _objectData(object){builds++;return EditorViewport.prototype._objectData.call(this,object);},
    _render(){if(this._geometryDirty)this._buildScene();if(this._selectedDirty)this._buildSelection();if(this._paintDirty)this._buildPaint();},
  });
  return {viewport,writes,deleted,uploads,get builds(){return builds;},clear(){writes.length=0;uploads.length=0;deleted.length=0;}};
}
function selectedFixture() {
  const ramp=createObject('surf'),f=fixture([ramp,createObject('block',[2000,0,0])]),v=f.viewport;
  v._buildScene();v.setSelected([ramp.id]);v._render();f.clear();v._hit=()=>({object:ramp});
  return {...f,ramp,get builds(){return f.builds;}};
}
function installLengthHandle(v) { v.surfHandles=[{field:'length',screen:[100,100],world:[0,0,0]}]; }
function noBaseUploads(f) { assert.ok(!f.uploads.some(u=>u.name==='solid'||u.name==='edges')); }

test('clicking a ramp in Move mode does not begin an edit or upload geometry',()=>{
  const f=selectedFixture(),v=f.viewport,before=structuredClone(f.ramp),base=f.builds,counts={start:0,change:0,end:0};
  v.callbacks={onTransformStart(){counts.start++;},onTransform(){counts.change++;},onTransformEnd(){counts.end++;}};
  v._pointerDown(event());v._pointerMove(event(102,100));v._pointerUp(event(102,100,{type:'pointerup'}));v._render();
  assert.deepEqual(counts,{start:0,change:0,end:0});assert.deepEqual(f.ramp,before);
  assert.equal(v._geometryDirty,false);assert.equal(f.builds,base);noBaseUploads(f);
  assert.equal(f.writes.length,0,'a no-op on the selected object leaves all geometry buffers intact');
});

test('opening Surf mode and clicking either the ramp or an unchanged handle stays outside history',()=>{
  const f=selectedFixture(),v=f.viewport,counts={start:0,change:0,end:0};
  v.callbacks={onTransformStart(){counts.start++;},onTransform(){counts.change++;},onTransformEnd(){counts.end++;}};
  v.setMode('surf');v._render();
  v._pointerDown(event(200,200));v._pointerUp(event(200,200,{type:'pointerup'}));v._render();
  installLengthHandle(v);v._pointerDown(event());v._pointerMove(event());v._pointerUp(event(100,100,{type:'pointerup'}));v._render();
  assert.deepEqual(counts,{start:0,change:0,end:0});assert.equal(v._geometryDirty,false);
  noBaseUploads(f);assert.equal(f.writes.length,0);
});

test('a real Move drag snapshots before mutation, starts once, and has one undo entry',()=>{
  const f=selectedFixture(),v=f.viewport,before=structuredClone(f.ramp),state=project(v.objects),history=new History(state);
  let starts=0,ends=0,snapshot=null;
  v.callbacks={onTransformStart(object){starts++;snapshot=structuredClone(object);},onTransformEnd(){ends++;history.commit(state);}};
  v._pointerDown(event());v._pointerMove(event(104,100));assert.equal(starts,0,'motion inside the snap cell changes nothing');
  v._pointerMove(event(140,100));v._pointerMove(event(172,100));
  assert.equal(starts,1);assert.deepEqual(snapshot,before);assert.notDeepEqual(f.ramp.position,before.position);
  v._pointerUp(event(172,100,{type:'pointerup'}));v._pointerUp(event(172,100,{type:'pointerup'}));
  assert.equal(ends,1);assert.equal(history.canUndo,true);assert.deepEqual(history.undo().objects[0],before);assert.equal(history.canUndo,false);
});

test('a surf handle starts one transaction before reshaping and cancellation restores all shape fields',()=>{
  const f=selectedFixture(),v=f.viewport,before=structuredClone(f.ramp);let starts=0,ends=0,snapshot=null;
  v.callbacks={onTransformStart(object){starts++;snapshot=structuredClone(object);},onTransformEnd(){ends++;}};
  v.setMode('surf');installLengthHandle(v);v._pointerDown(event());
  v._pointerMove(event(100,70));v._pointerMove(event(100,40));
  assert.equal(starts,1);assert.deepEqual(snapshot,before);assert.ok(f.ramp.size[1]>before.size[1]);
  v._pointerUp(event(100,40,{type:'pointercancel'}));v._render();
  assert.equal(ends,1);assert.deepEqual(f.ramp,before);
});

test('orbit and pan release leave mesh geometry clean',()=>{
  const f=selectedFixture(),v=f.viewport,base=f.builds;
  for(const button of [1,2]){v._pointerDown(event(100,100,{button}));v._pointerMove(event(140,120,{button}));v._pointerUp(event(140,120,{button,type:'pointerup'}));v._render();assert.equal(v._geometryDirty,false);}
  assert.equal(f.builds,base);noBaseUploads(f);assert.equal(f.writes.length,0);
});

test('Terminal Five surf reshaping uploads only its ramp, including changed triangle counts',async t=>{
  const {objects}=JSON.parse(await readFile(new URL('../dist/maps/bhop_terminal_five.bhop.json',import.meta.url),'utf8'));
  assert.ok(objects.length>=500,'exercise the actual large map');
  const f=fixture(objects),v=f.viewport;v._buildScene();
  const ramp=objects.find(o=>o.type==='surf');v.setSelected([ramp.id]);v._render();
  const beforeMeshes=new Map(v.meshes.map(m=>[m.object.id,m]));let lastCount=beforeMeshes.get(ramp.id).vertices.length,topologyChanged=false;
  const measurements=[];
  for(const shape of [{length:2048,bend:10},{length:3840,bend:150},{length:1024,bend:-60}]){
    f.clear();const builds=f.builds;Object.assign(ramp,reshapeSurf(ramp,shape));const started=performance.now();v.invalidate();v._render();const ms=performance.now()-started;
    const mesh=v.meshes.find(m=>m.object.id===ramp.id);
    assert.equal(f.builds,builds+1,'only the shaped ramp regenerates');noBaseUploads(f);
    for(const other of v.meshes)if(other.object.id!==ramp.id)assert.equal(other,beforeMeshes.get(other.object.id));
    const ownWrites=f.writes.filter(w=>w.buffer!==v.buffers.selected);
    assert.ok(ownWrites.length>=1);assert.ok(ownWrites.every(w=>w.buffer===mesh.solidBuffer||w.buffer===mesh.edgeBuffer),'no unchanged mesh receives GPU data');
    const bytes=ownWrites.reduce((sum,w)=>sum+w.bytes,0);assert.equal(bytes,(mesh.vertices.length+mesh.edges.length)*4);
    assert.equal(mesh.solidVertexCount,mesh.vertices.length/14);assert.equal(mesh.edgeVertexCount,mesh.edges.length/6);
    topologyChanged ||= mesh.vertices.length!==lastCount;lastCount=mesh.vertices.length;
    measurements.push({ms:Number(ms.toFixed(2)),bytes,triangles:mesh.triangles.length/3});
  }
  assert.equal(topologyChanged,true);t.diagnostic(objects.length+' objects: '+JSON.stringify(measurements)+'; no static geometry uploads');
});

test('removed ramps and viewport destruction release their dedicated buffers',()=>{
  const a=createObject('surf'),b=createObject('surf',[2000,0,0]),f=fixture([a,b]),v=f.viewport;
  v._buildScene();const aMesh=v.meshes[0],bMesh=v.meshes[1],removed=[aMesh.solidBuffer,aMesh.edgeBuffer].filter(Boolean);
  assert.equal(removed.length,2);f.clear();v.setScene([b]);v._render();
  for(const buffer of removed)assert.ok(f.deleted.includes(buffer),'removed ramp buffer is released');
  assert.ok(!f.deleted.includes(bMesh.solidBuffer));assert.ok(!f.deleted.includes(bMesh.edgeBuffer));
  const remaining=[bMesh.solidBuffer,bMesh.edgeBuffer];f.clear();v.destroy();for(const buffer of remaining)assert.ok(f.deleted.includes(buffer));assert.equal(v._meshCache.size,0);
});


test('context restoration recreates dedicated surf buffers before drawing again',()=>{
  const ramp=createObject('surf'),f=fixture([ramp,createObject('block',[2000,0,0])]),v=f.viewport;
  v._buildScene();const mesh=v.meshes[0],oldSolid=mesh.solidBuffer,oldEdges=mesh.edgeBuffer;
  assert.ok(oldSolid&&oldEdges);let id=1000;
  Object.assign(v.gl,{getExtension:()=>null,getShaderPrecisionFormat:()=>({precision:23}),
    createShader:()=>({shader:++id}),shaderSource(){},compileShader(){},getShaderParameter:()=>true,
    createProgram:()=>({program:++id}),attachShader(){},linkProgram(){},getProgramParameter:()=>true,deleteShader(){},
    getAttribLocation:()=>0,getUniformLocation:()=>({}),enable(){},disable(){},depthFunc(){},blendFunc(){},clearColor(){}});
  v._setupSkyRenderer=()=>{};f.clear();v._setupRenderer();
  assert.equal(mesh.solidBuffer,null);assert.equal(mesh.edgeBuffer,null);
  assert.equal(v._geometryDirty,true);v._render();
  assert.equal(v.meshes[0],mesh,'context loss retains CPU geometry');
  assert.ok(mesh.solidBuffer&&mesh.edgeBuffer);assert.notEqual(mesh.solidBuffer,oldSolid);assert.notEqual(mesh.edgeBuffer,oldEdges);
  assert.ok(f.writes.some(w=>w.buffer===mesh.solidBuffer));assert.ok(f.writes.some(w=>w.buffer===mesh.edgeBuffer));
});


test('rendering draws each surf buffer alongside the unchanged static map',()=>{
  const a=createObject('surf'),b=createObject('surf',[2000,0,0]),block=createObject('block'),f=fixture([a,block,b]),v=f.viewport;
  v._buildScene();v._buildPaint();const draws=[];
  Object.assign(v.gl,{viewport(){},clear(){},enable(){},disable(){},polygonOffset(){},depthMask(){}});
  Object.assign(v,{groundEnabled:false,gridEnabled:false,_overlayDirty:false,_animationStart:0,_reduceMotion:true,
    _drawSkybox:()=>false,_canAnimate:()=>false,
    _drawSolids(name,count,alpha,buffer=this.buffers[name]){draws.push({kind:'solid',name,count,buffer});},
    _drawLines(name,count,alpha,buffer=this.buffers[name]){draws.push({kind:'edges',name,count,buffer});}});
  EditorViewport.prototype._render.call(v);
  assert.equal(draws.find(d=>d.buffer===v.buffers.solid).count,v.meshes[1].vertices.length/14,'static mesh count excludes the ramps');
  for(const mesh of [v.meshes[0],v.meshes[2]]){
    assert.equal(draws.find(d=>d.kind==='solid'&&d.buffer===mesh.solidBuffer).count,mesh.vertices.length/14);
    assert.equal(draws.find(d=>d.kind==='edges'&&d.buffer===mesh.edgeBuffer).count,mesh.edges.length/6);
  }
});


test('in-place and loaded type replacements keep surf and static buffers in the right groups',()=>{
  const piece=createObject('block'),fixed=createObject('block',[2000,0,0]),f=fixture([piece,fixed]),v=f.viewport;
  const id=piece.id;v._buildScene();
  function checkStaticLayout(){
    const expected=v.meshes.filter(m=>m.object.type!=='surf').reduce((sum,m)=>sum+m.vertices.length,0);
    assert.equal(v.solidCount,expected/14);
    assert.equal(f.uploads.find(u=>u.name==='solid')?.length,expected,'static aggregate is rebuilt after either type transition');
  }
  f.clear();Object.assign(piece,createObject('surf'),{id});v.setScene([piece,fixed]);v._render();checkStaticLayout();
  const firstSurf=v.meshes[0],firstBuffers=[firstSurf.solidBuffer,firstSurf.edgeBuffer];assert.ok(firstBuffers.every(Boolean));
  f.clear();Object.assign(piece,createObject('block'),{id});delete piece.surf;v.setScene([piece,fixed]);v._render();checkStaticLayout();
  for(const buffer of firstBuffers)assert.ok(f.deleted.includes(buffer));
  const loadedRamp={...createObject('surf'),id};f.clear();v.setScene([loadedRamp,fixed]);v._render();checkStaticLayout();
  const loadedMesh=v.meshes[0],loadedBuffers=[loadedMesh.solidBuffer,loadedMesh.edgeBuffer];assert.ok(loadedBuffers.every(Boolean));
  const loadedBlock={...createObject('block'),id};f.clear();v.setScene([loadedBlock,fixed]);v._render();checkStaticLayout();
  for(const buffer of loadedBuffers)assert.ok(f.deleted.includes(buffer));
  assert.equal(v.meshes[1].object,fixed);
});
