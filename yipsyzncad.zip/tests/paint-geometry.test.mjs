import test from 'node:test';
import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import { createObject } from '../dist/model.js';
import { makeGeometry } from '../dist/viewport.js';
import { reshapeSurf, surfSections } from '../dist/surf.js';
import { makePaintPoint, paintPointToLocal, paintDiameter, buildPaintFaces, createPaintBuilder, MAX_PAINT_FACES } from '../dist/paint.js';
const near=(a,b,e=1e-6)=>assert.ok(Math.abs(a-b)<e,a+' ~= '+b);
const sub=(a,b)=>a.map((n,i)=>n-b[i]);
const dot=(a,b)=>a.reduce((s,n,i)=>s+n*b[i],0);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const triangle=(a,b,c)=>({points:[a,b,c],normal:[0,0,1]});
const quad=(x1,y1,x2,y2,z)=>[triangle([x1,y1,z],[x2,y1,z],[x2,y2,z]),triangle([x1,y1,z],[x2,y2,z],[x1,y2,z])];
const brush=(object,points,diameter=16)=>({color:'#ed39ad',size:diameter/Math.max(...object.size),points});
function liesOn(face,point) {
  if(Math.abs(dot(face.normal,sub(point,face.points[0])))>1e-5) return false;
  return face.points.every((a,i)=>dot(cross(face.normal,sub(face.points[(i+1)%3],a)),sub(point,a))>=-1e-5);
}
function assertOnMesh(painted,base) {
  assert.ok(painted.length>0);
  for(const face of painted) {
    assert.equal(face.emissive,true);assert.equal(face.color,'#ed39ad');near(Math.hypot(...face.normal),1);
    assert.ok(face.points.every(p=>p.every(Number.isFinite)));
    assert.ok(base.some(original=>dot(original.normal,face.normal)>.999&&face.points.every(p=>liesOn(original,p))),'Paint triangle must be clipped to one actual surface triangle');
  }
}
test('paint points remain attached to ordinary assets through moves, rotations and resizes',()=>{
  const object=createObject('block');object.size=[100,200,300];
  const point=makePaintPoint(object,[20,40,150],[0,0,1]);
  assert.deepEqual(point.position,[.2,.2,.5]);assert.equal(point.start,true);
  assert.deepEqual(paintPointToLocal(object,point),{position:[20,40,150],normal:[0,0,1]});
  object.position=[800,-920,300];object.rotation=[35,60,90];object.size=[200,100,600];
  assert.deepEqual(paintPointToLocal(object,point),{position:[40,20,300],normal:[0,0,1]});
  near(paintDiameter(object,{size:.025}),15);
});
test('a round brush clips to the real block face and never paints its underside or adjacent walls',()=>{
  const object=createObject('block'),base=makeGeometry(object).faces;
  object.paint=[brush(object,[makePaintPoint(object,[60,60,64],[0,0,1])],96)];
  const painted=buildPaintFaces(object,base);assertOnMesh(painted,base);
  for(const face of painted) {assert.ok(face.normal[2]>.999);for(const p of face.points) {near(p[2],64);assert.ok(p[0]<=64+1e-6&&p[1]<=64+1e-6);}}
});
test('shallow paint does not bleed onto a disconnected parallel surface behind a wall',()=>{
  const object=createObject('block'),front=quad(-64,-64,64,64,64),behind=quad(-64,-64,64,64,63.95);
  object.paint=[brush(object,[makePaintPoint(object,[0,0,64],[0,0,1])],64)];
  const painted=buildPaintFaces(object,[...front,...behind]);assertOnMesh(painted,front);
  for(const face of painted) for(const p of face.points) near(p[2],64);
});
test('disconnected stroke starts leave gaps without drawing bridges',()=>{
  const object=createObject('block'),base=makeGeometry(object).faces;
  const a=makePaintPoint(object,[-45,0,64],[0,0,1],true),b=makePaintPoint(object,[45,0,64],[0,0,1],true);
  object.paint=[brush(object,[a,b],12)];let painted=buildPaintFaces(object,base);assertOnMesh(painted,base);
  assert.ok(painted.every(f=>f.points.every(p=>Math.abs(p[0])>38.9)));
  b.start=false;painted=buildPaintFaces(object,base);assert.ok(painted.some(f=>f.points.some(p=>Math.abs(p[0])<10))||painted.some(f=>liesOn(f,[0,0,64])));
});
test('surf canonical points roundtrip and stay on the riding surface after every kind of ramp edit',()=>{
  const object=createObject('surf');Object.assign(object,reshapeSurf(object,{bend:75}));
  const sections=surfSections(object),section=sections[3],p=section.points[0].map((n,i)=>n+(section.points[1][i]-n)*.63);
  const base=makeGeometry(object).faces,top=base.find(f=>f.normal[2]>.2&&liesOn(f,p));assert.ok(top);
  const saved=makePaintPoint(object,p,top.normal);const roundtrip=paintPointToLocal(object,saved);
  for(let i=0;i<3;i++) near(roundtrip.position[i],p[i]);near(saved.position[2],.5);
  object.paint=[brush(object,[saved],24)];
  for(const change of [{width:512},{length:1920},{bend:-120},{slope:60},{side:-1},{bend:0},{slope:0}]) {
    Object.assign(object,reshapeSurf(object,change));const local=paintPointToLocal(object,saved),mesh=makeGeometry(object).faces;
    assert.ok(mesh.some(f=>f.normal[2]>.1&&liesOn(f,local.position)),JSON.stringify(change));
    const painted=buildPaintFaces(object,mesh);assertOnMesh(painted,mesh);assert.ok(painted.every(f=>f.normal[2]>.1));
  }
});
test('painted long surf strokes follow a newly bent strip instead of bridging its empty footprint',()=>{
  const object=createObject('surf'),a=makePaintPoint(object,[0,-460,8],[-Math.SQRT1_2,0,Math.SQRT1_2],true),b=makePaintPoint(object,[0,460,8],[-Math.SQRT1_2,0,Math.SQRT1_2],false);
  object.paint=[brush(object,[a,b],24)];Object.assign(object,reshapeSurf(object,{bend:130,length:1536,side:-1}));
  const base=makeGeometry(object).faces,painted=buildPaintFaces(object,base);assertOnMesh(painted,base);
  const along=painted.flatMap(f=>f.points.map(p=>p[1]));assert.ok(Math.max(...along)-Math.min(...along)>1000);assert.ok(painted.every(f=>f.normal[2]>.1));
});
test('mesh generation stays finite and within its explicit geometry budget',()=>{
  const object=createObject('block'),base=makeGeometry(object).faces,points=[];
  for(let i=0;i<4096;i++) points.push(makePaintPoint(object,[(i%2?1:-1)*48,((i%11)-5)*8,64],[0,0,1],i===0));
  object.paint=[brush(object,points,16)];const painted=buildPaintFaces(object,base);
  assert.ok(painted.length>10000&&painted.length<=MAX_PAINT_FACES);
  assert.ok(painted.every(f=>f.points.every(p=>p.every(Number.isFinite))));
});
test('typical 100-point surf and furnished-temple graffiti rebuilds stay responsive',t=>{
  for(const type of ['surf','egypttemple']) {
    const object=createObject(type);if(type==='surf') Object.assign(object,reshapeSurf(object,{bend:100}));
    const base=makeGeometry(object).faces,points=[];
    for(let i=0;i<100;i++) {
      let p,n;
      if(type==='surf') {const sections=surfSections(object),s=sections[Math.floor(i/100*(sections.length-1))];p=s.points[0].map((v,axis)=>v+(s.points[1][axis]-v)*.5);n=base.find(f=>f.normal[2]>.2&&liesOn(f,p))?.normal||[-Math.SQRT1_2,0,Math.SQRT1_2];}
      else {p=[600,-1100+i*22,-288];n=[0,0,1];}
      points.push(makePaintPoint(object,p,n,i===0));
    }
    object.paint=[brush(object,points,20)];const start=performance.now(),painted=buildPaintFaces(object,base),elapsed=performance.now()-start;
    assert.ok(painted.length>0);assert.ok(elapsed<3000,type+' build took '+elapsed+' ms');t.diagnostic(type+': '+base.length+' base faces, '+painted.length+' paint faces, '+elapsed.toFixed(1)+' ms');
  }
});

test('oversized imported brushes expose a bounded-work truncation signal',()=>{
  const object=createObject('egypttemple'),base=makeGeometry(object).faces,points=[];
  for(let i=0;i<4096;i++) points.push(makePaintPoint(object,[600,-1100+(i%100)*22,-288],[0,0,1],i===0));
  object.paint=[{color:'#ed39ad',size:2,points}];const start=performance.now(),painted=buildPaintFaces(object,base);
  assert.equal(painted.truncated,true);assert.ok(painted.length<=MAX_PAINT_FACES);assert.ok(performance.now()-start<3000);
});


test('incremental surf painting matches a full clipped build while returning only appended faces',()=>{
  const object=createObject('surf');Object.assign(object,reshapeSurf(object,{bend:95,length:1600}));
  const base=makeGeometry(object).faces,builder=createPaintBuilder(object,base);
  const empty=builder.update();assert.equal(empty.reset,true);assert.deepEqual(empty.addedFaces,[]);
  object.paint=[];let stroke=brush(object,[],20);object.paint.push(stroke);
  let previous=[],previousCount=0;
  for(let i=0;i<24;i++) {
    stroke.points.push({position:[-.3+(i%5)*.15,-.45+i*.035,.5],normal:[0,0,1],start:i===0||i===10});
    const result=builder.update(),full=buildPaintFaces(object,base);
    assert.deepEqual(result.faces,full);assert.equal(result.truncated,false);
    if(i) {assert.equal(result.reset,false);assert.equal(result.faces,previous);assert.equal(result.faces[0],previous[0]);}
    assert.equal(result.addedFaces.length,result.faces.length-previousCount);
    previous=result.faces;previousCount=result.faces.length;
  }
  const stable=builder.update();assert.equal(stable.reset,false);assert.equal(stable.faces,previous);assert.deepEqual(stable.addedFaces,[]);
  stroke=brush(object,[{position:[.2,.4,.5],normal:[0,0,1],start:true}],24);object.paint.push(stroke);
  const oldCount=previous.length,added=builder.update();assert.equal(added.reset,false);assert.equal(added.faces,previous);
  assert.equal(added.addedFaces.length,added.faces.length-oldCount);assert.deepEqual(added.faces,buildPaintFaces(object,base));assertOnMesh(added.faces,base);
});

test('incremental paint resets cleanly for undo, replacement, reorder and boundary-point edits',()=>{
  const object=createObject('block'),base=makeGeometry(object).faces,builder=createPaintBuilder(object,base);
  const a=makePaintPoint(object,[-30,-20,64],[0,0,1]),b=makePaintPoint(object,[20,20,64],[0,0,1],false);
  object.paint=[brush(object,[a,b],16),brush(object,[makePaintPoint(object,[35,-35,64],[0,0,1])],24)];builder.update();
  const resetAndCheck=()=>{const result=builder.update();assert.equal(result.reset,true);assert.deepEqual(Array.from(result.faces),Array.from(buildPaintFaces(object,base)));assert.deepEqual(result.addedFaces,Array.from(result.faces));};
  object.paint[1].points.push(makePaintPoint(object,[25,-25,64],[0,0,1],false));assert.equal(builder.update().reset,false);
  object.paint[1].points.pop();resetAndCheck();
  object.paint=[...object.paint];resetAndCheck();
  object.paint.reverse();resetAndCheck();
  object.paint[0].color='#00bbcc';resetAndCheck();
  object.paint[0].points[0].position[0]+=.03;resetAndCheck();
  // Appending to an earlier stroke needs a rebuild to preserve layer order.
  object.paint[0].points.push(makePaintPoint(object,[0,30,64],[0,0,1],false));resetAndCheck();
  object.paint.pop();resetAndCheck();delete object.paint;resetAndCheck();
});

test('incremental drawing retains the same per-object work cap across many updates',()=>{
  const object=createObject('egypttemple'),base=makeGeometry(object).faces,builder=createPaintBuilder(object,base);
  const stroke={color:'#ed39ad',size:2,points:[]};object.paint=[stroke];let result;
  for(let i=0;i<4096;i++) {
    stroke.points.push(makePaintPoint(object,[600,-1100+(i%100)*22,-288],[0,0,1],i===0));
    result=builder.update();
    if(result.truncated) break;
  }
  const full=buildPaintFaces(object,base);assert.equal(result.truncated,true);assert.equal(full.truncated,true);
  assert.ok(result.faces.length<=MAX_PAINT_FACES);assert.deepEqual(result.faces,full);
  const count=result.faces.length;stroke.points.push(makePaintPoint(object,[600,0,-288],[0,0,1],false));
  const capped=builder.update();assert.equal(capped.faces.length,count);assert.deepEqual(capped.addedFaces,[]);assert.equal(capped.truncated,true);
});

test('a single appended point avoids rebuilding a thousand saved surf points',t=>{
  const object=createObject('surf');Object.assign(object,reshapeSurf(object,{bend:110}));
  const base=makeGeometry(object).faces,stroke=brush(object,[],16);object.paint=[stroke];
  for(let i=0;i<1000;i++) stroke.points.push({position:[.05+Math.sin(i*.02)*.2,-.48+i*.00095,.5],normal:[0,0,1],start:i===0});
  const builder=createPaintBuilder(object,base);builder.update();
  stroke.points.push({position:[.05+Math.sin(1000*.02)*.2,.47,.5],normal:[0,0,1],start:false});
  let start=performance.now();const incremental=builder.update(),appendMs=performance.now()-start;
  start=performance.now();const full=buildPaintFaces(object,base),rebuildMs=performance.now()-start;
  assert.equal(incremental.reset,false);assert.ok(incremental.addedFaces.length>0&&incremental.addedFaces.length<100);
  assert.deepEqual(incremental.faces,full);assert.ok(appendMs<Math.max(20,rebuildMs*.2),'Appending one point took '+appendMs+' ms');
  t.diagnostic('1000 saved surf points: append '+appendMs.toFixed(2)+' ms; full rebuild '+rebuildMs.toFixed(2)+' ms; '+incremental.addedFaces.length+' new triangles');
});
