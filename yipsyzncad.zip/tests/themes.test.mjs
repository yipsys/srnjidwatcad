import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, access } from 'node:fs/promises';
import { THEME_ASSETS, THEME_PACKS } from '../dist/theme-assets.js';
import { TYPES, createObject, parseProject, serializeProject, duplicateObjects, History } from '../dist/model.js';
import { makeGeometry, EditorViewport } from '../dist/viewport.js';
const themedTypes=Object.keys(THEME_ASSETS);
const project=objects=>({format:'bhop-builder',version:2,name:'Four worlds',objects,environment:{skybox:'none',rotation:0,brightness:1}});
function pick(type,origin,direction){
 const viewport=Object.create(EditorViewport.prototype),piece=createObject(type);
 const mesh=viewport._objectData(piece);
 viewport.meshes=[{object:piece,triangles:mesh.triangles}]; viewport._geometryDirty=false;
 viewport._updateCamera=()=>{}; viewport._ray=()=>({origin,direction});
 return viewport._hit(0,0);
}
test('four themed packs expose 32 distinct original pieces with matching palette and thumbnails',async()=>{
 assert.deepEqual(Object.keys(THEME_PACKS),['viking','egyptian','moon','space']);
 assert.equal(themedTypes.length,32);
 const html=await readFile(new URL('../dist/index.html',import.meta.url),'utf8');
 for(const [key,pack] of Object.entries(THEME_PACKS)){
  assert.equal(pack.types.length,8); assert.equal(new Set(pack.types).size,8);
  assert.equal(pack.positions.length,8);
  assert.ok(html.includes('value="'+key+'"'));
  for(const type of pack.types){
   assert.ok(Object.hasOwn(TYPES,type));
   assert.equal(THEME_ASSETS[type].category,key);
   assert.equal(html.split('data-piece="'+type+'"').length-1,1);
   await access(new URL('../dist/assets/thumbnails/'+type+'.svg',import.meta.url));
  }
 }
});
test('every themed piece survives transforms, recolouring, group copy, save and undo',()=>{
 const objects=themedTypes.map((type,i)=>{const p=createObject(type,[i*420,0,TYPES[type].size[2]/2]);p.rotation=[0,0,i*9];p.size=p.size.map(n=>n*1.25);p.material=i%2?'weathered':'pulse-violet';p.color='#6a9bcd';return p});
 const original=project(objects),history=new History(original);
 const copies=duplicateObjects(objects,[0,2048,64]),changed=project([...objects,...copies]);
 history.commit(changed);
 const reopened=parseProject(serializeProject(changed));
 assert.deepEqual(reopened,changed); assert.deepEqual(history.undo(),original); assert.deepEqual(history.redo(),changed);
 copies.forEach((copy,i)=>{assert.notEqual(copy.id,objects[i].id);assert.deepEqual(copy.size,objects[i].size);assert.equal(copy.material,objects[i].material);});
});
test('themed meshes stay distinct and practical in triangle count',()=>{
 const signatures=new Set();
 for(const type of themedTypes){
  const geometry=makeGeometry(createObject(type));
  assert.ok(geometry.faces.length>=12,type+' nonempty mesh');
  assert.ok(geometry.faces.length<=3000,type+' triangle budget');
  signatures.add(JSON.stringify(geometry));
 }
 assert.equal(signatures.size,32);
});
test('Egyptian and space gates preserve open entrances in native picking',()=>{
 assert.equal(pick('egyptpylon',[0,-200,-20],[0,1,0]),null);
 assert.ok(pick('egyptpylon',[190,-200,-20],[0,1,0]));
 assert.equal(pick('spaceairlock',[0,-200,0],[0,1,0]),null);
 assert.ok(pick('spaceairlock',[128,-200,0],[0,1,0]));
 assert.equal(pick('spacecorridor',[0,-300,0],[0,1,0]),null);
 assert.ok(pick('spacecorridor',[116,-300,0],[0,1,0]));
});
test('lunar crater has a physical depressed floor below its rim',()=>{
 const center=pick('mooncrater',[0,0,200],[0,0,-1]);
 const rim=pick('mooncrater',[145,0,200],[0,0,-1]);
 assert.ok(center&&rim); assert.ok(rim.point[2]>center.point[2]+10);
});
test('Viking longhouse entrance and lander leg gaps remain empty',()=>{
 assert.equal(pick('vikinglonghouse',[0,-400,-70],[0,1,0]),null);
 assert.ok(pick('vikinglonghouse',[140,-400,-70],[0,1,0]));
 assert.equal(pick('moonlander',[0,-240,-90],[0,1,0]),null);
});
