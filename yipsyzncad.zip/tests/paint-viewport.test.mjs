import test from 'node:test';
import assert from 'node:assert/strict';
import { createObject, PAINT_LIMITS } from '../dist/model.js';
import { EditorViewport } from '../dist/viewport.js';

function fixture() {
  const object = createObject('block', [0, 0, 64]);
  const events = [];
  const viewport = Object.create(EditorViewport.prototype);
  Object.assign(viewport, {
    objects: [object], paintBrush: {color:'#ff4bb8',size:24}, worldPerPixel:1, mode:'paint',
    selectedIds:[], selectedId:null, callbacks:{
      onPaintStart: () => events.push('start'), onPaintEnd: (_object,canceled) => events.push(canceled ? 'cancel' : 'end'),
      onPaintLimit: () => events.push('limit'),
    },
    canvas: {getBoundingClientRect:() => ({left:0,top:0}),setPointerCapture() {},hasPointerCapture:() => false,style:{}},
    _updateCamera() {},
    invalidate() {},invalidatePaint() { this._paintDirty = true; },
    _emitSelection(ids) { this.selectedIds = ids; this.selectedId = ids.at(-1); },
    _hit(x,y) { return {object,point:[x,y,128],localPoint:[x,y,64],localNormal:[0,0,1],normal:[0,0,1]}; },
  });
  return {viewport,object,events};
}
test('one pointer gesture creates one attached stroke and one undo transaction', () => {
  const {viewport,object,events} = fixture();
  viewport._beginPaint({clientX:-30,clientY:0,pointerId:1});
  viewport._paintMove({clientX:30,clientY:0,pointerId:1},viewport.drag);
  viewport._pointerUp({pointerId:1,type:'pointerup'});
  assert.deepEqual(events,['start','end']);
  assert.equal(object.paint.length,1);
  assert.ok(object.paint[0].points.length > 10);
  assert.equal(object.paint[0].points[0].start,true);
  assert.equal(viewport.selectedId,object.id);
  assert.equal(viewport.drag,null);
});
test('empty space and other objects break a stroke instead of painting a bridge', () => {
  const {viewport,object} = fixture();
  viewport._beginPaint({clientX:-30,clientY:0,pointerId:1});
  viewport._appendPaintHit(null);
  viewport._appendPaintHit({...viewport._hit(30,0),object:createObject('block')});
  viewport._appendPaintHit(viewport._hit(30,0));
  assert.equal(object.paint[0].points.length,2);
  assert.equal(object.paint[0].points[1].start,true);
});
test('cancel restores existing paint without committing the new stroke', () => {
  const {viewport,object,events} = fixture();
  viewport._beginPaint({clientX:0,clientY:0,pointerId:1});
  viewport._pointerUp({pointerId:1,type:'pointerup'});
  const saved = JSON.stringify(object.paint);
  viewport._beginPaint({clientX:20,clientY:0,pointerId:2});
  viewport._pointerUp({cancel:true});
  assert.equal(JSON.stringify(object.paint),saved);
  assert.deepEqual(events,['start','end','start','cancel']);
});
test('paint limits stop a gesture before starting an empty transaction', () => {
  const {viewport,object,events} = fixture();
  object.paint = Array.from({length:PAINT_LIMITS.maxStrokes}, () => ({color:'#ffffff',size:.1,points:[]}));
  viewport._beginPaint({clientX:0,clientY:0,pointerId:1});
  assert.deepEqual(events,['limit']); assert.equal(viewport.drag,undefined);
});
test('brush on a tiny asset stays inside the supported saved size range', () => {
  const {viewport,object} = fixture();
  object.size = [1,1,1]; viewport.paintBrush.size = 128;
  viewport._hit = () => ({object,point:[0,0,.5],localPoint:[0,0,.5],localNormal:[0,0,1],normal:[0,0,1]});
  viewport._beginPaint({clientX:0,clientY:0,pointerId:1});
  assert.ok(object.paint[0].size <= PAINT_LIMITS.maxSize);
});

test('scrolling while drawing cannot shift the camera and add stray paint', () => {
  const {viewport} = fixture();
  viewport.camera = {distance:1000};
  viewport._beginPaint({clientX:0,clientY:0,pointerId:1});
  let prevented = false;
  viewport._wheel({deltaY:120,preventDefault() { prevented = true; }});
  assert.equal(prevented,true); assert.equal(viewport.camera.distance,1000);
});
