import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,access} from 'node:fs/promises';
import {RAIL_ASSETS,RAIL_PACKS} from '../dist/rail-assets.js';
import {TYPES,createObject,createDemo,duplicateObjects,parseProject,serializeProject,History} from '../dist/model.js';
import {EditorViewport,makeGeometry} from '../dist/viewport.js';
import {makePaintPoint,buildPaintFaces} from '../dist/paint.js';
const railTypes=Object.keys(RAIL_ASSETS);
function picker(type,changes={}) {
 const piece=createObject(type,[0,0,TYPES[type].size[2]/2]);Object.assign(piece,changes);
 const viewport=Object.create(EditorViewport.prototype),data=viewport._objectData(piece);
 viewport.meshes=[{...data,object:piece}];viewport._geometryDirty=false;viewport._updateCamera=()=>{};
 return (origin,direction)=>{viewport._ray=()=>({origin,direction});return viewport._hit(0,0);};
}
test('station kit exposes exactly twenty original assets and matching category, previews and local thumbnails',async()=>{
 assert.equal(railTypes.length,20);assert.equal(new Set(railTypes).size,20);
 assert.deepEqual(RAIL_PACKS['rail-all'].types,railTypes);
 const subpacks=['rail-vehicles','rail-infrastructure','rail-props'];
 assert.deepEqual(subpacks.flatMap(key=>RAIL_PACKS[key].types),railTypes);
 assert.equal(RAIL_PACKS['rail-vehicles'].types.length,4);
 const html=await readFile(new URL('../dist/index.html',import.meta.url),'utf8');
 assert.ok(html.includes('value="rail"'));
 for(const key of Object.keys(RAIL_PACKS)) {assert.ok(html.includes('value="'+key+'"'));assert.equal(RAIL_PACKS[key].positions.length,RAIL_PACKS[key].types.length);}
 for(const type of railTypes) {
   assert.equal(TYPES[type].category,'rail');assert.equal(html.split('data-piece="'+type+'"').length-1,1);
   await access(new URL('../dist/assets/thumbnails/'+type+'.svg',import.meta.url));
 }
});
test('all station pieces persist with transforms, materials, independent copies and history',()=>{
 const state=createDemo();
 const pieces=railTypes.map((type,i)=>{const p=createObject(type,[i*1024,3000,TYPES[type].size[2]/2]);p.rotation=[5,10,i*9];p.size=p.size.map(n=>n*1.15);p.color='#849ca6';return p;});
 state.objects.push(...pieces);const history=new History(state),changed=structuredClone(state);
 const copies=duplicateObjects(pieces,[0,6000,40]);changed.objects.push(...copies);history.commit(changed);
 assert.deepEqual(parseProject(serializeProject(changed)),changed);assert.deepEqual(history.undo(),state);assert.deepEqual(history.redo(),changed);
 copies[0].size[0]=999;assert.notEqual(pieces[0].size[0],999);
});
test('station meshes have practical triangle budgets and distinguishable, recolorable silhouettes',()=>{
 const signatures=new Set();
 for(const type of railTypes) {
  const mesh=makeGeometry(createObject(type));assert.ok(mesh.faces.length>24,type+' detailed geometry');
  assert.ok(mesh.faces.length<=6500,type+' practical mesh budget');
  assert.ok(mesh.faces.some(face=>!face.color),type+' recolorable main structure');
  signatures.add(JSON.stringify(mesh));
 }
 assert.equal(signatures.size,20,'every station piece has distinct geometry');
 for(const type of ['railcommuter','raillocomotive','railcarriage','railwagon']) assert.ok(makeGeometry(createObject(type)).faces.length>800,type+' real rolling-stock detail');
 const signal=makeGeometry(createObject('railsignal'));
 for(const color of ['#db4c49','#edba52','#5cb889']) assert.ok(signal.faces.some(face=>face.emissive&&face.color===color),color+' lit signal lens');
});
test('passenger carriage admits a player-sized route through both ends with a furnished interior',()=>{
 const pick=picker('railcarriage');
 for(const x of [-48,0,48]) for(const z of [120,200,300]) {
  assert.equal(pick([x,-900,z],[0,1,0]),null,'longitudinal aisle '+x+'/'+z);
  assert.equal(pick([x,900,z],[0,-1,0]),null,'return route '+x+'/'+z);
 }
 const floor=pick([0,0,600],[0,0,-1]);assert.ok(floor);assert.ok(Math.abs(floor.point[2]-80.256)<.01);
 assert.ok(pick([0,-900,330],[0,1,0]),'header remains a real solid above the doorway');
 assert.equal(pick([-500,-288,250],[1,0,0]),null,'side window opening is real');
 const rotated=picker('railcarriage',{rotation:[0,0,90],position:[1024,2048,176]});
 assert.equal(rotated([128,2048,220],[1,0,0]),null,'rotated aisle stays open');
});
test('freight wagon has an open cargo well and station shelter keeps its front open',()=>{
 const wagon=picker('railwagon'),inside=wagon([0,0,500],[0,0,-1]),rim=wagon([140,0,500],[0,0,-1]);
 assert.ok(inside&&rim);assert.ok(rim.point[2]>inside.point[2]+60,'cargo bed is recessed');
 const [sx,sy,sz]=TYPES.railshelter.size,shelter=picker('railshelter');
 assert.equal(shelter([0,0,sz/2],[0,-1,0]),null,'no wall across shelter entrance');
 assert.equal(shelter([0,0,sz/2],[1,0,0]),null,'shelter side walking space');
 const ground=shelter([0,0,sz*.85],[0,0,-1]);assert.ok(ground);assert.ok(ground.point[2]<40,'shelter centre reaches its floor');
});
test('native graffiti paints a carriage floor and remains independently attached after copying',()=>{
 const piece=createObject('railcarriage');
 const point=makePaintPoint(piece,[0,0,-.272*piece.size[2]],[0,0,1]);
 piece.paint=[{color:'#35dcea',size:32/Math.max(...piece.size),points:[point]}];
 const painted=buildPaintFaces(piece,makeGeometry(piece).faces);assert.ok(painted.length>0);
 const [copy]=duplicateObjects([piece],[512,0,40]);assert.deepEqual(copy.paint,piece.paint);assert.notEqual(copy.paint,piece.paint);
 copy.paint[0].points[0].position[0]=.1;assert.equal(piece.paint[0].points[0].position[0],0);
});

test('tracks keep their rail gauge and actual sleeper gaps while platform markings are flush',()=>{
 const track=picker('railtrack');
 for(const x of [-80,80]) {const rail=track([x,40,200],[0,0,-1]);assert.ok(rail);assert.ok(Math.abs(rail.point[2]-40)<.01);}
 assert.equal(track([0,40,200],[0,0,-1]),null,'gap between ties is not a solid rectangular asset');
 const platform=picker('railplatform');
 for(const x of [0,-235.52,235.52]) {const top=platform([x,0,400],[0,0,-1]);assert.ok(top);assert.ok(top.point[2]<=112.01&&top.point[2]>=111.4,'tiles share a level top with shallow grout');}
 const curve=makeGeometry(createObject('railcurve')).faces;
 assert.ok(curve.filter(f=>Math.abs(f.normal[0])>.01&&Math.abs(f.normal[1])>.01).length>30,'curved rail side normals follow the arc');
});
test('station footbridge, canopy and entrance preserve usable passages',()=>{
 const bridge=picker('railfootbridge');
 assert.equal(bridge([0,-1000,400],[0,1,0]),null,'bridge clears a 352-unit train standing on 40-unit track');
 const standing=bridge([-1000,0,560],[1,0,0]);assert.equal(standing,null,'centre walkway has no crosswise obstruction');
 const down=bridge([0,0,600],[0,0,-1]);assert.ok(down);assert.ok(Math.abs(down.point[2]-384/704*832)<.01,'flat raised walking deck');
 const canopy=picker('railcanopy');assert.equal(canopy([0,-800,224],[0,1,0]),null,'platform aisle stays open under canopy');
 const entrance=picker('railentrance');assert.equal(entrance([0,-500,200],[0,1,0]),null,'station entrance doorway');
 assert.ok(entrance([330,-500,200],[0,1,0]),'entrance side tower stays solid');
});

test('both footbridge stairways have sixteen real treads with default rises below thirty-two units',()=>{
 const bridge=picker('railfootbridge'),size=TYPES.railfootbridge.size;
 for(const sign of [-1,1]) {
  let prior=0;
  for(let i=0;i<16;i++) {
   const x=sign*(.5-(i+.5)*.31/16)*size[0];
   const hit=bridge([x,0,600],[0,0,-1]);assert.ok(hit);
   const expected=(i+1)*384/704*size[2]/16;assert.ok(Math.abs(hit.point[2]-expected)<.01);
   assert.ok(hit.point[2]-prior<=32);prior=hit.point[2];
  }
 }
});
