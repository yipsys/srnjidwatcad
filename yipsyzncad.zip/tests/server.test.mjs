import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import http from 'node:http';
import { once } from 'node:events';
import { setTimeout as delay } from 'node:timers/promises';

test('local server serves only editor assets and rejects unexpected hosts and writes', async () => {
  const port = 4187;
  const child = spawn(process.execPath, ['server.mjs'], { cwd: new URL('../', import.meta.url), env: { ...process.env, BHOP_PORT: String(port) }, stdio: ['ignore', 'pipe', 'pipe'] });
  try {
    await Promise.race([
      new Promise((resolve, reject) => {
        child.stdout.once('data', resolve);
        child.once('error', reject);
        child.once('exit', code => reject(new Error(`Server exited before ready: ${code}`)));
      }),
      delay(5000, undefined, { ref: false }).then(() => { throw new Error('Server did not start'); }),
    ]);
    const origin = `http://127.0.0.1:${port}`;
    const asset = await fetch(origin + '/model.js');
    assert.equal(asset.status, 200);
    assert.match(asset.headers.get('content-security-policy'), /connect-src 'none'/);
    assert.match(asset.headers.get('content-type'), /javascript/);
    const outside = await fetch(origin + '/README.md');
    assert.equal(outside.status, 404);
    const unexpectedHost = await new Promise((resolve, reject) => {
      const req = http.request(origin + '/model.js', { headers: { host: 'example.com' } }, res => { res.resume(); resolve({ status: res.statusCode }); });
      req.on('error', reject); req.end();
    });
    assert.equal(unexpectedHost.status, 403);
    const write = await fetch(origin + '/model.js', { method: 'POST', body: 'anything' });
    assert.equal(write.status, 405);
    const traversal = await fetch(origin + '/..%2Fserver.mjs');
    assert.ok([403, 404].includes(traversal.status));
  } finally {
    child.kill();
    await once(child, 'exit').catch(() => {});
  }
});

