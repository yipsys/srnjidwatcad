import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp,writeFile,mkdir,readFile,rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import {join} from 'node:path';
import {createObject,serializeProject} from '../dist/model.js';
import {DEFAULT_MOVEMENT} from '../dist/playtest-physics.js';
import {exportCss,brushPlanes} from '../desktop/css-export.mjs';
import {compileProject} from '../desktop/compile-css.mjs';
function project(){const o=createObject('platform',[0,0,16]);o.size=[512,512,32];return {format:'bhop-builder',version:2,name:'Test',objects:[o],environment:{skybox:'none',rotation:0,brightness:1},playtest:{spawn:{position:[0,0,33],yaw:90},movement:{...DEFAULT_MOVEMENT}}};}
test('CSS export creates enclosure, spawn and unique brush ids with correct plane halfspaces',()=>{
 const result=exportCss(project());assert.equal(result.brushCount,7);assert.match(result.vmf,/info_player_counterterrorist/);assert.match(result.vmf,/"origin" "0 0 34"/);
 const ids=[...result.vmf.matchAll(/"id" "(\d+)"/g)].map(m=>m[1]);assert.equal(new Set(ids).size,ids.length);
 for(const type of ['block','platform','wall','ramp','surf']){const o=createObject(type);o.rotation=[12,20,35];assert.ok(brushPlanes(o).length>=5);}
});
test('CSS export rejects unsupported geometry, missing/blocked spawns and excessive bounds',()=>{
 let p=project();p.objects.push(createObject('tree'));assert.throws(()=>exportCss(p),/Unsupported/);
 p=project();const surf=createObject('surf',[600,0,136]);surf.surf.bend=30;p.objects.push(surf);assert.throws(()=>exportCss(p),/Curved/);
 p=project();delete p.playtest;assert.throws(()=>exportCss(p),/spawn/);
 p=project();p.playtest.spawn.position=[0,0,0];assert.throws(()=>exportCss(p),/overlaps/);
 p=project();p.objects[0].position[0]=16000;assert.throws(()=>exportCss(p),/bounds/);
 p=project();p.objects[0].collision=false;assert.throws(()=>exportCss(p),/Non-solid/);
});
test('compiler validates tools, runs fixed ordered commands and verifies BSP magic/version',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'bhop-css-'));
 try{
 const config={project:join(dir,'map.json'),game:join(dir,'cstrike'),tools:join(dir,'bin'),output:join(dir,'out')};
 await mkdir(config.game);await mkdir(config.tools);await writeFile(join(config.game,'gameinfo.txt'),'GameInfo { "SteamAppId" "240" }');await writeFile(config.project,serializeProject(project()));
 await assert.rejects(compileProject(config,{log:()=>{}}),/Missing vbsp/);
 for(const t of ['vbsp','vvis','vrad'])await writeFile(join(config.tools,t+'.exe'),'test placeholder');
 const calls=[];const execute=async(exe,args)=>{calls.push([exe,args]);if(exe.endsWith('vbsp.exe')){const h=Buffer.alloc(1036);h.write('VBSP');h.writeInt32LE(20,4);await writeFile(args[2].replace(/\.vmf$/,'.bsp'),h);}};
 const bsp=await compileProject(config,{execute,log:()=>{}});assert.equal(calls.length,3);assert.ok(calls[1][0].endsWith('vvis.exe'));assert.equal(calls[0][1][0],'-game');assert.equal((await readFile(bsp)).toString('ascii',0,4),'VBSP');
 await assert.rejects(compileProject(config,{execute:async()=>{},log:()=>{}}),/ENOENT/);
 await assert.rejects(compileProject(config,{execute:async()=>{throw Error('tool failure');},log:()=>{}}),/tool failure/);
 }finally{await rm(dir,{recursive:true,force:true});}
});


test('serialized VMF plane winding encloses the original platform',()=>{
 const p=project(),vmf=exportCss(p).vmf;
 const planes=[...vmf.matchAll(/"plane" "\(([^)]+)\) \(([^)]+)\) \(([^)]+)\)"/g)].slice(0,6);
 assert.equal(planes.length,6);
 const sub=(a,b)=>a.map((v,i)=>v-b[i]);
 const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
 for(const m of planes){
  const [a,b,c]=m.slice(1).map(s=>s.split(' ').map(Number));
  const n=cross(sub(a,b),sub(c,b));
  assert.ok(Math.hypot(...n)>0);
  for(const x of [-256,256])for(const y of [-256,256])for(const z of [0,32]){
   assert.ok(n.reduce((sum,v,i)=>sum+v*([x,y,z][i]-a[i]),0)<=.001);
  }
 }
});
