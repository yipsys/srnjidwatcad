import test from 'node:test';
import assert from 'node:assert/strict';
import { TYPES, PAINT_LIMITS, DEFAULT_ENVIRONMENT, createObject, createDemo, validateProject, serializeProject, parseProject, duplicateObject, duplicateObjects, repeatObjects, History } from '../dist/model.js';
import { arrayObjects } from '../dist/build-tools.js';

const point = (position = [0, 0, .5], normal = [0, 0, 1], start = true) => ({ position, normal, start });
const stroke = (count = 3) => ({ color: '#ea3278', size: .035, points: Array.from({ length: count }, (_, i) => point([i / Math.max(1, count), 0, .5], [0, 0, 1], i === 0)) });
function project(objects = [createObject('surf')]) {
  return { format: 'bhop-builder', version: 2, name: 'Painted course', environment: { ...DEFAULT_ENVIRONMENT }, objects };
}
function painted(type = 'surf', count = 3) {
  const object = createObject(type); object.paint = [stroke(count)]; return object;
}
function rejectsPaint(mutator, pattern) {
  const value = project([painted()]); mutator(value.objects[0].paint, value); assert.throws(() => validateProject(value), pattern);
}

test('paint stays optional on existing assets and legacy drafts without changing the file version', () => {
  const value = project(Object.keys(TYPES).map(type => createObject(type)));
  const restored = parseProject(serializeProject(value));
  assert.deepEqual(restored, value); assert.ok(restored.objects.every(object => !Object.hasOwn(object, 'paint')));
  const legacy = { format: 'bhop-builder', version: 1, name: 'Legacy course', objects: [createObject('surf'), createObject('platform')] };
  assert.deepEqual(parseProject(JSON.stringify(legacy)), { ...legacy, version: 2, environment: { ...DEFAULT_ENVIRONMENT } });
  const empty = project([createObject('block')]); empty.objects[0].paint = [];
  assert.deepEqual(parseProject(serializeProject(empty)), empty);
});

test('surface strokes roundtrip for surf ramps and ordinary assets as independent plain data', () => {
  const value = project([painted('surf'), painted('block')]);
  value.objects[0].surf.bend = 60; value.objects[0].rotation = [0, 0, 45];
  value.objects[0].paint[0].points.push(point([-.5, -.5, -.5], [1, 0, 0], true));
  value.objects[1].paint[0].color = '#AABBCC'; value.objects[1].paint[0].points[0].normal = [0, 0, .999];
  const restored = parseProject(serializeProject(value));
  assert.equal(restored.version, 2); assert.equal(restored.objects[1].paint[0].color, '#aabbcc');
  assert.deepEqual(restored.objects[1].paint[0].points[0].normal, [0, 0, 1]);
  assert.deepEqual(restored.objects[0].paint, value.objects[0].paint); assert.deepEqual(restored.objects[0].surf, value.objects[0].surf);
  assert.notEqual(restored.objects[0].paint, value.objects[0].paint);
  assert.notEqual(restored.objects[0].paint[0].points[0].position, value.objects[0].paint[0].points[0].position);
  restored.objects[0].paint[0].points[0].position[0] = -.8;
  assert.equal(value.objects[0].paint[0].points[0].position[0], 0);
  restored.objects[0].paint[0].color = '#123456'; assert.equal(value.objects[0].paint[0].color, '#ea3278');
});

test('paint rejects malformed fields, numeric values and invalid surface coordinates', () => {
  rejectsPaint((paint, value) => { value.objects[0].paint = null; }, /paint.*(array|strokes)/i);
  rejectsPaint(paint => { paint[0].extra = true; }, /unsupported/);
  rejectsPaint(paint => { delete paint[0].size; }, /missing|unsupported/);
  rejectsPaint(paint => { paint[0].points[0].extra = true; }, /unsupported/);
  rejectsPaint(paint => { delete paint[0].points[0].normal; }, /missing|unsupported/);
  for (const color of ['#fff', 'red', 'url(https://example.com/image)', '#abcdef00', 123]) rejectsPaint(paint => { paint[0].color = color; }, /color/i);
  for (const size of [0, -.1, Infinity, NaN, '0.1', PAINT_LIMITS.minSize / 2, PAINT_LIMITS.maxSize + .01]) rejectsPaint(paint => { paint[0].size = size; }, /size.*finite|finite.*size/i);
  for (const position of [[1.001, 0, 0], [0, -1.001, 0], [0, 0, NaN], ['.5', 0, 0], [0, 0]]) rejectsPaint(paint => { paint[0].points[0].position = position; }, /position|three numbers/);
  for (const normal of [[0, 0, 0], [0, 0, .8], [1, 1, 0], [0, 0, 1.1], [NaN, 0, 1]]) rejectsPaint(paint => { paint[0].points[0].normal = normal; }, /normal|finite number/);
  rejectsPaint(paint => { paint[0].points = []; }, /at least one|non.empty|1–4096/i);
  rejectsPaint(paint => { paint[0].points[0].start = false; }, /first|start/i);
  rejectsPaint(paint => { paint[0].points[1].start = 1; }, /boolean|start/i);
  for (const size of [PAINT_LIMITS.minSize, PAINT_LIMITS.maxSize]) {
    const value = project([painted()]); value.objects[0].paint[0].size = size;
    value.objects[0].paint[0].points = [point([-1, 1, 0], [-1, 0, 0])];
    assert.equal(validateProject(value).objects[0].paint[0].size, size);
  }
});

test('nested paint inputs cannot contain executable getters, forbidden keys, cycles or sparse arrays', () => {
  const unsafe = project([painted()]);
  Object.defineProperty(unsafe.objects[0].paint[0].points[0], 'constructor', { enumerable: true, value: {} });
  assert.throws(() => serializeProject(unsafe), /forbidden/);
  const raw = JSON.stringify(project([painted()])).replace('"points":[', '"__proto__":{},"points":[');
  assert.throws(() => parseProject(raw), /forbidden/); assert.equal({}.polluted, undefined);
  const getters = project([painted()]);
  Object.defineProperty(getters.objects[0].paint[0].points[0], 'normal', { enumerable: true, get() { throw new Error('getter must never run'); } });
  assert.throws(() => serializeProject(getters), /plain data/);
  const cyclic = project([painted()]); cyclic.objects[0].paint[0].points[0].position = cyclic.objects[0].paint;
  assert.throws(() => serializeProject(cyclic), /cycles/);
  const custom = project([painted()]); Object.setPrototypeOf(custom.objects[0].paint[0], { custom: true });
  assert.throws(() => validateProject(custom), /prototype/);
  const shared = project([painted()]); shared.objects[0].paint[0].points[1] = shared.objects[0].paint[0].points[0];
  assert.throws(() => validateProject(shared), /shared object/);
  rejectsPaint((paint, value) => { value.objects[0].paint = Array(2); }, /plain data|consecutive|object|entries/);
  rejectsPaint(paint => { paint[0].points = Array(2); }, /plain data|consecutive|object|entries/);
  rejectsPaint(paint => { paint[0].points[0].position = Array(3); }, /plain data|consecutive|finite number|entries/);
  rejectsPaint(paint => { paint[0].points[0].normal = Array(3); }, /plain data|consecutive|finite number|entries/);
  assert.throws(() => parseProject(' '.repeat(8 * 1024 * 1024 + 1)), /8 MB/);
});

test('paint budgets accept exact boundaries and reject oversized objects and projects', () => {
  assert.deepEqual(PAINT_LIMITS, { maxStrokes: 256, maxObjectPoints: 4096, maxProjectPoints: 20000, minSize: .000001, maxSize: 2 });
  const strokes = project([painted()]); strokes.objects[0].paint = Array.from({ length: PAINT_LIMITS.maxStrokes }, () => stroke(1));
  assert.equal(validateProject(strokes).objects[0].paint.length, PAINT_LIMITS.maxStrokes);
  strokes.objects[0].paint.push(stroke(1)); assert.throws(() => validateProject(strokes), /256/);
  assert.equal(validateProject(project([painted('surf', PAINT_LIMITS.maxObjectPoints)])).objects[0].paint[0].points.length, PAINT_LIMITS.maxObjectPoints);
  assert.throws(() => validateProject(project([painted('surf', PAINT_LIMITS.maxObjectPoints + 1)])), /4096/);
  const combined = painted(); combined.paint = [stroke(2048), stroke(2049)];
  assert.throws(() => validateProject(project([combined])), /4096/);
  const budget = project(Array.from({ length: 5 }, () => painted('block', 4000)));
  assert.equal(validateProject(budget).objects.length, 5);
  budget.objects.push(painted('surf', 1)); assert.throws(() => validateProject(budget), /20000/);
});

test('copy, repeat, array and history preserve graffiti without sharing strokes or point arrays', () => {
  const source = painted();
  const copies = [
    duplicateObject(source, [256, 0, 0]),
    ...duplicateObjects([source], [0, 256, 0]),
    ...repeatObjects(source, { count: 2, gap: 32 }),
    ...arrayObjects([source], { columns: 2, rows: 2, gapX: 32, gapY: 32 }),
  ];
  assert.ok(copies.length >= 6);
  for (const copy of copies) {
    assert.notEqual(copy.id, source.id); assert.deepEqual(copy.paint, source.paint);
    assert.notEqual(copy.paint, source.paint); assert.notEqual(copy.paint[0], source.paint[0]);
    assert.notEqual(copy.paint[0].points, source.paint[0].points);
    assert.notEqual(copy.paint[0].points[0].normal, source.paint[0].points[0].normal);
  }
  copies[0].paint[0].points[0].position[0] = -.25; assert.equal(source.paint[0].points[0].position[0], 0);
  assert.equal(copies[1].paint[0].points[0].position[0], 0);
  const state = createDemo(); const history = new History(state);
  state.objects.push(source); assert.equal(history.commit(state), true);
  const prior = history.undo(); assert.equal(prior.objects.length, 11);
  const paintedState = history.redo(); assert.deepEqual(paintedState.objects.at(-1).paint, source.paint);
  paintedState.objects.at(-1).paint[0].color = '#000000';
  history.undo(); assert.equal(history.redo().objects.at(-1).paint[0].color, '#ea3278');
  delete state.objects.at(-1).paint; history.commit(state);
  assert.ok(Object.hasOwn(history.undo().objects.at(-1), 'paint'));
  assert.ok(!Object.hasOwn(history.redo().objects.at(-1), 'paint'));
});
