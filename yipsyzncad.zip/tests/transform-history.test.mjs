import test from 'node:test';
import assert from 'node:assert/strict';
import { createDemo, createObject, History } from '../dist/model.js';
import { reshapeSurf } from '../dist/surf.js';

test('direct transform history commits validate before changing the undo timeline', () => {
  const project = createDemo(), history = new History(project);
  project.objects[0].position[0] = Infinity;
  assert.throws(() => history.commit(project), /finite number/);
  assert.equal(history.canUndo, false); assert.equal(history.canRedo, false);
  project.objects[0].position[0] = -800;
  assert.equal(history.commit(project), true);
  assert.equal(history.undo().objects[0].position[0], -960);
  const changed = history.redo(); assert.equal(changed.objects[0].position[0], -800);
});

test('committing a reshaped surf ramp preserves live object and unrelated paint identities', () => {
  const project = createDemo(), ramp = createObject('surf'); project.objects.push(ramp);
  const sign = project.objects[0];
  sign.paint = [{ color: '#ff00aa', size: .1, points: [{ position: [0, 0, .5], normal: [0, 0, 1], start: true }] }];
  const paint = sign.paint, stroke = paint[0], point = stroke.points[0], history = new History(project);
  Object.assign(ramp, reshapeSurf(ramp, { length: 1536, bend: 45 }));
  assert.equal(history.commit(project), true);
  assert.equal(project.objects[0], sign); assert.equal(sign.paint, paint);
  assert.equal(sign.paint[0], stroke); assert.equal(stroke.points[0], point);
  const previous = history.undo(), redone = history.redo();
  assert.notEqual(previous.objects.at(-1).size[1], 1536);
  assert.equal(redone.objects.at(-1).size[1], 1536); assert.equal(redone.objects.at(-1).surf.bend, 45);
  assert.deepEqual(redone.objects[0].paint, paint);
});
