import test from 'node:test';
import assert from 'node:assert/strict';
import { TYPES, parseProject, serializeProject, worldAxisSize } from '../dist/model.js';
import { EditorViewport } from '../dist/viewport.js';
import { DEFAULT_DRAFT_KEY, resolveCourseConfig, draftKeyFor } from '../dist/course-projects.js';
import { createTerminalFive, TERMINAL_ROUTES, TERMINAL_STAGE_Y } from '../dist/maps/terminal-five.js';

const idMap = project => new Map(project.objects.map(object => [object.id, object]));
const isCourseSurface = object => /^(?:route-r[1-5]-(?:warmup-[1-6]|stage-[1-4]-hop-\d+)|checkpoint-[0-4]|course-start|finish-link|course-finish)$/.test(object.id);
const top = object => object.position[2] + object.size[2] / 2;
const edgeGap = (a,b) => Math.hypot(
  Math.max(0, Math.abs(b.position[0]-a.position[0]) - (worldAxisSize(a,0)+worldAxisSize(b,0))/2),
  Math.max(0, Math.abs(b.position[1]-a.position[1]) - (worldAxisSize(a,1)+worldAxisSize(b,1))/2)
);
function sequence(project, route, stage) {
  const byId = idMap(project);
  const hops = project.objects.filter(object => object.id.startsWith('route-' + route.id + '-stage-' + stage + '-hop-'))
    .sort((a,b) => a.position[1]-b.position[1]);
  return [byId.get('checkpoint-' + (stage-1)), ...hops, byId.get('checkpoint-' + stage)];
}
function picker(objects) {
  const viewport = Object.create(EditorViewport.prototype);
  viewport.meshes = objects.map(object => ({...viewport._objectData(object),object}));
  viewport._geometryDirty = false; viewport._updateCamera = () => {};
  return (origin,direction) => { viewport._ray = () => ({origin,direction}); return viewport._hit(0,0); };
}

test('terminal course is a valid editable project containing every available asset and independent objects', () => {
  const project = createTerminalFive();
  assert.ok(project.objects.length > 200, 'large station course');
  assert.ok(project.objects.length <= 2000, 'within existing editor project capacity');
  assert.equal(new Set(project.objects.map(object => object.id)).size,project.objects.length);
  assert.deepEqual([...new Set(project.objects.map(object => object.type))].sort(),Object.keys(TYPES).sort());
  assert.deepEqual(parseProject(serializeProject(project)),project);
  const other = createTerminalFive(), original = other.objects[0].position.slice();
  project.objects[0].position[0] += 100;
  assert.deepEqual(other.objects[0].position,original,'a new map does not share editable vectors');
});

test('five distinguishable routes share switchable stage plazas and six clear preparation hops', () => {
  const project = createTerminalFive(), byId = idMap(project);
  assert.equal(TERMINAL_ROUTES.length,5);
  assert.equal(new Set(TERMINAL_ROUTES.map(route => route.id)).size,5);
  assert.equal(new Set(TERMINAL_ROUTES.map(route => route.color)).size,5);
  assert.ok(Object.isFrozen(TERMINAL_ROUTES));
  assert.ok(TERMINAL_ROUTES.every(Object.isFrozen));
  assert.equal(TERMINAL_STAGE_Y.length,5);
  for (let stage=0; stage<TERMINAL_STAGE_Y.length; stage++) {
    const plaza = byId.get('checkpoint-' + stage);
    assert.ok(plaza && plaza.collision && plaza.visible,'real shared landing plaza');
    assert.equal(plaza.position[1],TERMINAL_STAGE_Y[stage]);
    for (const route of TERMINAL_ROUTES) {
      assert.ok(Math.abs(route.x-plaza.position[0])+route.padSize/2 < plaza.size[0]/2,'every lane enters a common plaza');
    }
  }
  for (const route of TERMINAL_ROUTES) {
    const warmups = Array.from({length:6}, (_,index) => byId.get('route-'+route.id+'-warmup-'+(index+1)));
    assert.ok(warmups.every(Boolean),'six warm-up pads for '+route.name);
    const path = [byId.get('course-start'), ...warmups, byId.get('checkpoint-0')];
    for (let i=1;i<path.length;i++) {
      assert.ok(path[i].position[1] > path[i-1].position[1],'warm-up progresses toward course');
      assert.ok(edgeGap(path[i-1],path[i]) <= 192,'warm-up has conservative gaps');
      assert.equal(top(path[i]),top(path[i-1]),'preparation lane preserves landing elevation');
    }
    for (const pad of warmups) {
      assert.equal(pad.position[0],route.x);
      assert.ok(pad.collision && pad.visible);
      assert.ok(pad.size[0]>=256 && pad.size[1]>=256,'generous SSJ preparation landing');
    }
  }
});

test('actual route footprints progress from short to long gaps without disconnected stages or overlaps', () => {
  const project = createTerminalFive();
  let previousMinimum = -Infinity, previousHopCount = Infinity;
  for (const route of TERMINAL_ROUTES) {
    const gaps = [];
    assert.ok(route.hopsPerStage < previousHopCount,'higher route uses fewer longer jumps');
    previousHopCount = route.hopsPerStage;
    for (let stage=1;stage<TERMINAL_STAGE_Y.length;stage++) {
      const path = sequence(project,route,stage);
      assert.equal(path.length,route.hopsPerStage+2);
      assert.ok(path.every(Boolean),'each stage connects its entry and exit plazas');
      for (let index=1;index<path.length;index++) {
        const a = path[index-1], b = path[index], gap = edgeGap(a,b);
        assert.ok(b.position[1] > a.position[1],'ordered northbound route');
        assert.ok(gap>0,'separated hop landings');
        assert.ok(gap<768,'no disconnected coordinate jump');
        assert.equal(top(a),top(b),'difficulty comes from gaps rather than hidden elevation jumps');
        gaps.push(gap);
      }
      for (const pad of path.slice(1,-1)) {
        assert.ok(pad.collision && pad.visible);
        assert.ok(Math.abs(pad.position[0]-route.x)<=400,'route remains inside its lane');
        assert.ok(pad.size[0]>=192 && pad.size[1]>=192,'usable landing footprint');
      }
    }
    const minimum = Math.min(...gaps), maximum = Math.max(...gaps);
    assert.ok(minimum > previousMinimum+50,'minimum required gap increases by route');
    assert.ok(maximum-minimum<128,'one route has consistent jump demand');
    previousMinimum = minimum;
  }
});

test('scenic track beds and themed exhibits cannot form hidden solid shortcuts', () => {
  const project = createTerminalFive();
  for (const object of project.objects) {
    if (isCourseSurface(object)) {
      assert.ok(object.collision && object.visible,object.id+' real visible course surface');
    } else {
      assert.equal(object.collision,false,object.id+' scenery stays outside playable collision');
    }
  }
  const byId=idMap(project);
  assert.ok(top(byId.get('course-finish'))>=top(byId.get('checkpoint-4')),'finish remains usable');
});

test('native geometry gives every course pad a flat landing and player-sized overhead clearance', () => {
  const project = createTerminalFive();
  const course = project.objects.filter(isCourseSurface);
  const pick = picker(course);
  for (const object of course) {
    const z = top(object), [x,y] = object.position;
    for (const [dx,dy] of [[0,0],[-.3,-.3],[.3,.3]]) {
      const hit=pick([x+dx*object.size[0],y+dy*object.size[1],z+256],[0,0,-1]);
      assert.ok(hit,object.id+' has a native landing surface');
      assert.equal(hit.object.id,object.id,'expected pad is uppermost at landing');
      assert.ok(Math.abs(hit.point[2]-z)<.01,object.id+' level top');
      assert.ok(hit.normal[2]>.99,object.id+' upward landing normal');
      const ceiling=pick([x+dx*object.size[0],y+dy*object.size[1],z+1],[0,0,1]);
      assert.ok(!ceiling || ceiling.point[2]-z>=128,object.id+' clear jumping headroom');
    }
  }
});

test('the new course chooses a separate browser draft without changing the ordinary editor key', () => {
  assert.equal(DEFAULT_DRAFT_KEY,'bhop-builder:local-draft:v1');
  for (const query of ['', '?foo=bar', '?course=unknown', '?course=']) {
    assert.equal(resolveCourseConfig(query),null);
    assert.equal(draftKeyFor(query),DEFAULT_DRAFT_KEY);
  }
  const course=resolveCourseConfig('?course=terminal-five');
  assert.equal(course.id,'terminal-five');
  assert.equal(draftKeyFor('?course=terminal-five'),course.storageKey);
  assert.notEqual(course.storageKey,DEFAULT_DRAFT_KEY);
  assert.equal(draftKeyFor('?foo=bar&course=terminal-five'),course.storageKey);
});
