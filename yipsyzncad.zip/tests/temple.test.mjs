import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, access } from 'node:fs/promises';
import { TEMPLE_BASE_SIZE, TEMPLE_ROUTE, TEMPLE_ASSETS } from '../dist/temple-assets.js';
import { TYPES, createObject, createDemo, duplicateObjects, suggestedGroupOffset, History, parseProject, serializeProject } from '../dist/model.js';
import { EditorViewport, makeGeometry } from '../dist/viewport.js';
function nativePicker(extra={}){
 const viewport=Object.create(EditorViewport.prototype),piece={...createObject('egypttemple',[0,0,320]),...extra};
 viewport.meshes=[{object:piece,triangles:viewport._objectData(piece).triangles}];viewport._geometryDirty=false;viewport._updateCamera=()=>{};
 return(origin,direction)=>{viewport._ray=()=>({origin,direction});return viewport._hit(0,0);};
}
test('temple section has thirteen conservative landings and connects both doorways',()=>{
 assert.deepEqual(TYPES.egypttemple.size,TEMPLE_BASE_SIZE);assert.equal(TEMPLE_ROUTE.length,13);
 assert.equal(TEMPLE_ROUTE[0].y,-1344);assert.equal(TEMPLE_ROUTE.at(-1).y,1344);
 for(let i=1;i<TEMPLE_ROUTE.length;i++){
  const a=TEMPLE_ROUTE[i-1],b=TEMPLE_ROUTE[i];
  assert.equal(b.y-a.y,224);assert.ok(Math.abs(b.top-a.top)<=16);
  const gap=b.y-a.y-(a.depth+b.depth)/2;assert.ok(gap>=0&&gap<=48);
  assert.ok(Math.hypot(b.x-a.x,b.y-a.y)<=259);
 }
 for(const step of TEMPLE_ROUTE)assert.ok(Math.abs(step.x)+step.width/2+16<240,'landing and player-width clearance');
});
test('every temple landing is a real flat surface and floor is recessed in the gaps',()=>{
 const pick=nativePicker();
 for(const step of TEMPLE_ROUTE){
  const hit=pick([step.x,step.y,500],[0,0,-1]);assert.ok(hit,step.name);assert.ok(Math.abs(hit.point[2]-step.top)<=.5,step.name+' correct landing height');
 }
 const floor=pick([0,112,400],[0,0,-1]);assert.ok(floor);assert.ok(Math.abs(floor.point[2]-32)<=1,'gap reaches room floor');
});
test('temple doors and central lane are clear at standing head height',()=>{
 const pick=nativePicker();
 for(const x of[-200,0,200])assert.equal(pick([x,-1800,220],[0,1,0]),null,'full central passage clear');
 for(const step of TEMPLE_ROUTE){
  const ceiling=pick([step.x,step.y,step.top+72],[0,0,1]);assert.ok(!ceiling||ceiling.point[2]>=520,'generous overhead clearance');
 }
 assert.ok(pick([850,-1800,220],[0,1,0]),'surrounding portal is solid');
 const rotated=nativePicker({position:[320,-160,320],rotation:[0,0,90]});
 assert.equal(rotated([2120,-160,220],[-1,0,0]),null,'rotated temple passage remains clear');
});
test('furnished temple is bounded, recolorable and keeps a reasonable composite mesh budget',()=>{
 const piece=createObject('egypttemple'),mesh=makeGeometry(piece);
 assert.ok(mesh.faces.length>600);assert.ok(mesh.faces.length<=16000);
 assert.ok(mesh.faces.some(face=>face.emissive),'torch accents');assert.ok(mesh.faces.some(face=>!face.color),'recolorable sandstone');
 const colors=new Set(mesh.faces.map(face=>face.color).filter(Boolean));assert.ok(colors.size>=5,'gold, blue, fire and furnishing details');
});
test('a temple places, duplicates and saves as one independent editable map object',()=>{
 const temple=createObject('egypttemple',[2048,0,320]);temple.rotation=[0,0,90];
 const original=createDemo();original.objects.push(temple);const history=new History(original);
 const [copy]=duplicateObjects([temple],suggestedGroupOffset([temple],128));
 const changed=structuredClone(original);changed.objects.push(copy);history.commit(changed);
 assert.deepEqual(parseProject(serializeProject(changed)),changed);assert.deepEqual(history.undo(),original);assert.deepEqual(history.redo(),changed);
 assert.equal(changed.objects.length-original.objects.length,1);assert.notEqual(copy.id,temple.id);assert.deepEqual(copy.rotation,temple.rotation);
});
test('temple is offered in the Egyptian library and its dedicated preview with a local thumbnail',async()=>{
 assert.equal(TYPES.egypttemple.category,'egyptian');assert.ok(TEMPLE_ASSETS.egypttemple.keywords.includes('bhop'));
 const html=await readFile(new URL('../dist/index.html',import.meta.url),'utf8');assert.equal(html.split('data-piece="egypttemple"').length-1,1);assert.ok(html.includes('value="temple"'));
 await access(new URL('../dist/assets/thumbnails/egypttemple.svg',import.meta.url));
});
