
import test from 'node:test';
import assert from 'node:assert/strict';
import {CollisionWorld,Player,DEFAULT_MOVEMENT,TICK} from '../dist/playtest-physics.js';
import {createObject,createDemo,parseProject,serializeProject,History} from '../dist/model.js';
import {EditorViewport} from '../dist/viewport.js';
import {reshapeSurf,surfSections} from '../dist/surf.js';
function mesh(o) {return {object:o,...EditorViewport.prototype._objectData.call({},o)};}
function box(pos,size) {const o=createObject('block',pos);o.size=size;return o;}
const floor=()=>box([0,0,-16],[12000,12000,32]);
function player(objects=[floor()],spawn=[0,0,.1]) {return new Player(new CollisionWorld(objects.map(mesh)),{position:spawn,yaw:0});}
function run(p,n,input={}) {for(let i=0;i<n;i++)p.advance(TICK,input);}
test('spawn settings survive export/import, undo/redo and old drafts remain valid',()=>{
  const p=createDemo(),h=new History(p);
  p.playtest={spawn:{position:[12,34,56],yaw:90},movement:{...DEFAULT_MOVEMENT}};
  h.commit(p);assert.deepEqual(parseProject(serializeProject(p)).playtest,p.playtest);
  assert.equal(h.undo().playtest,undefined);assert.deepEqual(h.redo().playtest,p.playtest);
  for(const patch of [NaN,Infinity,-1,5000]) {
    const broken=structuredClone(p);broken.playtest.movement.gravity=patch;
    assert.throws(()=>serializeProject(broken));
  }
  const bad=structuredClone(p);bad.playtest.spawn.position=[1,2];assert.throws(()=>serializeProject(bad));
  const extra=structuredClone(p);extra.playtest.movement.foo=1;assert.throws(()=>serializeProject(extra));
});
test('player settles on real floor; walking accelerates and release applies friction',()=>{
  const p=player();run(p,60);assert.ok(p.grounded);assert.ok(Math.abs(p.position[2])<.1);
  run(p,120,{forward:1});assert.ok(p.position[0]>200);assert.ok(p.velocity[0]>250);
  run(p,120);assert.ok(Math.hypot(...p.velocity)<.01);
});
test('jump has expected apex and hold-space automatically hops without removing momentum',()=>{
  const p=player();run(p,10);p.velocity[0]=600;
  let apex=0;for(let i=0;i<80;i++){p.advance(TICK,{jump:true});apex=Math.max(apex,p.position[2]);}
  assert.ok(apex>55&&apex<59,apex);assert.ok(p.velocity[0]>599);
  run(p,150,{jump:true});assert.ok(p.jumps>=3,p.jumps);assert.ok(p.velocity[0]>599);
});
test('air strafing adds sideways speed; mouse-relative right is screen right',()=>{
  const p=player([], [0,0,1000]);p.velocity[0]=400;
  run(p,1,{right:1});assert.ok(p.velocity[1]<0);assert.ok(Math.hypot(p.velocity[0],p.velocity[1])>400);
  p.yaw=Math.PI/2;p.velocity=[0,0,0];run(p,1,{forward:1});assert.ok(p.velocity[1]>0);assert.ok(Math.abs(p.velocity[0])<.01);
});
test('high speed swept collision stops at thin walls and platforms',()=>{
  const p=player([floor(),box([100,0,64],[2,1000,128])]);
  run(p,5);p.velocity=[3000,0,0];run(p,10);
  assert.ok(p.position[0]<=83.01,p.position);assert.ok(p.velocity[0]<1);
  const q=player([box([0,0,-.5],[1000,1000,1])],[0,0,20]);q.velocity=[0,0,-3000];run(q,5);
  assert.ok(q.position[2]>=-.01,q.position);
});
test('ceilings stop upward jumps and corners constrain both axes',()=>{
  const p=player([floor(),box([0,0,110],[1000,1000,10])]);run(p,10);run(p,20,{jump:true});
  assert.ok(p.position[2]+72<=105.1,p.position);
  const q=player([floor(),box([100,0,64],[2,1000,128]),box([0,100,64],[1000,2,128])]);
  run(q,5);q.velocity=[2500,2500,0];run(q,20);
  assert.ok(q.position[0]<=83.1&&q.position[1]<=83.1,q.position);
});
test('non-solid and invisible assets do not block; spawn overlap and enclosed spawn are rejected',()=>{
  const solid=box([0,0,100],[500,500,500]),w=new CollisionWorld([mesh(solid)]);
  assert.equal(w.clear([0,0,50]),false);assert.equal(w.clear([260,0,50]),false);
  assert.equal(w.clear([600,0,50]),true);
  solid.collision=false;assert.equal(new CollisionWorld([mesh(solid)]).clear([0,0,50]),true);
  solid.collision=true;solid.visible=false;assert.equal(new CollisionWorld([mesh(solid)]).meshes.length,0);
});
test('actual straight surf ramp produces a slide and preserves along-ramp momentum',()=>{
  const ramp=createObject('surf');ramp.size=[1024,6000,1040];
  const p=player([ramp],[200,-1000,400]);p.velocity=[0,500,0];
  let surfTicks=0;for(let i=0;i<120;i++){p.advance(TICK);if(p.surfing)surfTicks++;}
  assert.ok(surfTicks>5,{surfTicks,position:p.position});assert.ok(p.position[0]<100,p.position);
  assert.ok(p.velocity[1]>490,p.velocity);assert.ok(!p.grounded);
});
test('bent and rotated surf ramps collide with their actual triangular surfaces',()=>{
  for(const bend of [-90,90]) {
    const ramp=createObject('surf');Object.assign(ramp,reshapeSurf(ramp,{width:512,length:3000,bend}));
    ramp.rotation[2]=35;ramp.position=[1000,500,800];
    const m=mesh(ramp),w=new CollisionWorld([m]);
    const tri=m.localFaces.findIndex(f=>f.normal[2]>.3&&f.normal[2]<.72);
    assert.ok(tri>=0);
    const vertices=m.triangles.slice(tri*3,tri*3+3),point=[0,1,2].map(i=>vertices.reduce((s,v)=>s+v[i],0)/3);
    const hit=w.trace([point[0],point[1],point[2]+160],[0,0,-300]);
    assert.ok(hit && hit.time<1);assert.ok(hit.normal[2]>.3&&hit.normal[2]<.72,hit);
  }
});
test('fixed steps agree at different frame rates and large stalls are bounded',()=>{
  const a=player(),b=player();
  for(let i=0;i<240;i++)a.advance(1/120,{forward:1,jump:true});
  for(let i=0;i<60;i++)b.advance(1/30,{forward:1,jump:true});
  for(let i=0;i<3;i++)assert.ok(Math.abs(a.position[i]-b.position[i])<1e-6);
  b.advance(100,{forward:1});assert.ok(Math.abs(b.position[0]-a.position[0])<100);
});
test('restart and falling reset position, look, velocity and held simulation time',()=>{
  const p=player();run(p,30,{forward:1,jump:true});p.yaw=2;p.pitch=1;p.reset();
  assert.deepEqual(p.position,[0,0,.1]);assert.deepEqual(p.velocity,[0,0,0]);assert.equal(p.yaw,0);assert.equal(p.pitch,0);
  p.position[2]=-3000;run(p,1);assert.deepEqual(p.position,[0,0,.1]);
});
test('first-person camera uses eye height and leaves editor orbit camera unchanged',()=>{
  const v=Object.create(EditorViewport.prototype),camera={target:[1,2,3],distance:1234,azimuth:.4,elevation:.8};
  Object.assign(v,{firstPerson:{position:[100,200,300],yaw:Math.PI/2,pitch:0},camera,width:1000,height:600});
  v._updateCamera();assert.deepEqual(v.eye,[100,200,364]);assert.ok(v.forward[1]>.999);assert.deepEqual(v.camera,camera);
});
