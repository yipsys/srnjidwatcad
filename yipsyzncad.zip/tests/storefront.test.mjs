import test from 'node:test';
import assert from 'node:assert/strict';
import { access, readFile } from 'node:fs/promises';
import { TYPES, createObject, createDemo, duplicateObjects, History, parseProject, serializeProject } from '../dist/model.js';
import { makeGeometry, EditorViewport } from '../dist/viewport.js';
function pick(origin,direction,extra={}){
 const viewport=Object.create(EditorViewport.prototype),piece={...createObject('sevenelevenfront'),...extra};
 viewport.meshes=[{object:piece,triangles:viewport._objectData(piece).triangles}];
 viewport._geometryDirty=false;viewport._updateCamera=()=>{};viewport._ray=()=>({origin,direction});
 return viewport._hit(0,0);
}
test('storefront facade has a walk-through entrance, real windows and empty interior space',()=>{
 assert.equal(pick([0,-500,-75],[0,1,0]),null);
 assert.ok(pick([400,-500,-75],[0,1,0]),'window exists');
 assert.ok(pick([0,-500,135],[0,1,0]),'fascia exists');
 assert.equal(pick([0,256,1000],[0,0,-1]),null,'rear interior remains unbuilt');
 assert.equal(pick([-2000,256,0],[1,0,0]),null,'no interior side walls');
 assert.equal(pick([820,0,-75],[-1,0,0],{rotation:[0,0,90],position:[320,0,0]}),null,'rotated doorway opening remains clear');
});
test('storefront has fixed orange, green and red sign details over a recolorable facade',()=>{
 const piece=createObject('sevenelevenfront'),geometry=makeGeometry(piece);
 assert.ok(geometry.faces.length>200);assert.ok(geometry.faces.length<3000);
 const colors=new Set(geometry.faces.map(face=>face.color).filter(Boolean));
 assert.ok(colors.size>=6,'separate frame, glazing and sign colors');
 assert.ok(geometry.faces.some(face=>!face.color),'facade retains object color');
 const viewport=Object.create(EditorViewport.prototype);
 const a=viewport._objectData({...piece,color:'#cc3333'}),b=viewport._objectData({...piece,color:'#3366cc'});
 assert.notDeepEqual(a.vertices,b.vertices);
});
test('front facade stays editable through resizing, copies, save and history',()=>{
 const piece=createObject('sevenelevenfront',[2048,-1024,192]);piece.size=[2048,160,448];piece.rotation=[0,0,35];
 const original=createDemo();original.objects.push(piece);const history=new History(original);
 const changed=structuredClone(original);changed.objects.push(...duplicateObjects([piece],[0,1024,0]));history.commit(changed);
 const reopened=parseProject(serializeProject(changed));assert.deepEqual(reopened,changed);
 assert.deepEqual(history.undo(),original);assert.deepEqual(history.redo(),changed);
 assert.equal(reopened.objects.at(-1).type,'sevenelevenfront');assert.deepEqual(reopened.objects.at(-1).size,piece.size);
});
test('storefront is available in Street and the dedicated preview with a local native thumbnail',async()=>{
 assert.equal(TYPES.sevenelevenfront.category,'street');assert.ok(TYPES.sevenelevenfront.keywords.includes('7/11'));
 const html=await readFile(new URL('../dist/index.html',import.meta.url),'utf8');
 assert.equal(html.split('data-piece="sevenelevenfront"').length-1,1);assert.ok(html.includes('value="storefronts"'));
 await access(new URL('../dist/assets/thumbnails/sevenelevenfront.svg',import.meta.url));
});
