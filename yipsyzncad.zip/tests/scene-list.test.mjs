import test from 'node:test';
import assert from 'node:assert/strict';
import { createSceneList } from '../dist/scene-list.js';

function fixture({ placeholder = false } = {}) {
  const stats = { created: 0, tree: 0, classes: 0, attributes: 0 };
  class Element {
    constructor(tag, document) {
      this.tagName = tag; this.ownerDocument = document; this.children = []; this.parentNode = null;
      this.dataset = {}; this.style = {}; this.attributes = new Map(); this.classes = new Set(); this.textContent = '';
      this.classList = { toggle: (name, active) => { stats.classes++; active ? this.classes.add(name) : this.classes.delete(name); }, contains: name => this.classes.has(name) };
    }
    get firstChild() { return this.children[0] || null; }
    get nextSibling() { return this.parentNode?.children[this.parentNode.children.indexOf(this) + 1] || null; }
    setAttribute(name, value) { stats.attributes++; this.attributes.set(name, value); }
    getAttribute(name) { return this.attributes.get(name); }
    append(...children) { for (const child of children) this.insertBefore(child, null); }
    insertBefore(child, next) {
      stats.tree++; if (child.parentNode) child.remove();
      const index = next ? this.children.indexOf(next) : this.children.length;
      assert.ok(index >= 0); this.children.splice(index, 0, child); child.parentNode = this;
    }
    remove() {
      if (!this.parentNode) return; stats.tree++;
      this.parentNode.children.splice(this.parentNode.children.indexOf(this), 1); this.parentNode = null;
      if (this.ownerDocument.activeElement === this) this.ownerDocument.activeElement = null;
    }
  }
  const document = { activeElement: null, createElement(tag) { stats.created++; return new Element(tag, document); } };
  const list = new Element('div', document), count = new Element('span', document);
  if (placeholder) list.append(new Element('div', document));
  const renderer = createSceneList(list, { block: { label: 'Block' }, surf: { label: 'Surf ramp' } }, count);
  return { document, list, count, renderer, stats, reset() { for (const key of Object.keys(stats)) stats[key] = 0; } };
}
const piece = (id, fields = {}) => ({ id, name: 'Piece ' + id, type: 'block', color: '#ffffff', ...fields });

test('large-map selection changes only the two affected rows without recreating or detaching nodes', t => {
  const f = fixture(), objects = Array.from({ length: 535 }, (_, i) => piece(String(i)));
  f.renderer.sync(objects, ['0']);
  assert.equal(f.stats.created, 1605);
  const first = f.list.children[0], last = f.list.children.at(-1);
  f.document.activeElement = last; f.list.scrollTop = 720; f.reset();
  f.renderer.select(['534']);
  assert.deepEqual(f.stats, { created: 0, tree: 0, classes: 2, attributes: 2 });
  assert.equal(f.list.children[0], first); assert.equal(f.list.children.at(-1), last);
  assert.equal(f.document.activeElement, last); assert.equal(f.list.scrollTop, 720);
  assert.equal(first.getAttribute('aria-pressed'), 'false'); assert.equal(last.getAttribute('aria-pressed'), 'true');
  t.diagnostic('535-row selection: 0 node creations, 0 tree mutations, 2 selected-class changes and 2 aria updates; previous full rebuild created 1,605 nodes.');
});

test('multi-selection adds and removes only changed members and repeated selection is inert', () => {
  const f = fixture(); f.renderer.sync(['a', 'b', 'c'].map(id => piece(id)), ['a', 'b']); f.reset();
  f.renderer.select(['b', 'c']);
  assert.deepEqual(f.list.children.map(row => row.getAttribute('aria-pressed')), ['false', 'true', 'true']);
  assert.deepEqual(f.stats, { created: 0, tree: 0, classes: 2, attributes: 2 });
  f.reset(); f.renderer.select(['c', 'b']);
  assert.deepEqual(f.stats, { created: 0, tree: 0, classes: 0, attributes: 0 });
});

test('project edits reuse scene rows and refresh names, colours and types without tree changes', () => {
  const f = fixture(), objects = [piece('a'), piece('b')]; f.renderer.sync(objects, ['a']);
  const rows = [...f.list.children]; f.reset();
  f.renderer.sync([piece('a', { name: 'Curved ramp', type: 'surf', color: '#ff00aa' }), piece('b')], ['a']);
  assert.equal(f.stats.created, 0); assert.equal(f.stats.tree, 0);
  assert.equal(f.list.children[0], rows[0]); assert.equal(f.list.children[1], rows[1]);
  assert.equal(rows[0].children[1].textContent, 'Curved ramp');
  assert.equal(rows[0].children[0].style.backgroundColor, '#ff00aa'); assert.equal(rows[0].title, 'Surf ramp');
  assert.equal(rows[0].getAttribute('aria-pressed'), 'true'); assert.equal(f.count.textContent, '2 objects');
});

test('new, deleted, reordered and restored objects produce the correct list and selection', () => {
  const f = fixture(); f.renderer.sync([piece('a'), piece('b'), piece('c')], ['b']);
  const a = f.list.children[0], c = f.list.children[2];
  f.renderer.sync([piece('c'), piece('d'), piece('a')], ['d']);
  assert.deepEqual(f.list.children.map(row => row.dataset.objectId), ['c', 'd', 'a']);
  assert.equal(f.list.children[0], c); assert.equal(f.list.children[2], a);
  assert.deepEqual(f.list.children.map(row => row.getAttribute('aria-pressed')), ['false', 'true', 'false']);
  f.renderer.sync([piece('a'), piece('b'), piece('c')], ['b']);
  assert.deepEqual(f.list.children.map(row => row.dataset.objectId), ['a', 'b', 'c']);
  assert.deepEqual(f.list.children.map(row => row.getAttribute('aria-pressed')), ['false', 'true', 'false']);
  f.renderer.sync([piece('b')], ['b']); assert.equal(f.count.textContent, '1 object');
  f.renderer.sync([], []); assert.equal(f.count.textContent, '0 objects'); assert.equal(f.list.children.length, 0);
});

test('initial placeholders are cleared once while later edits retain focused scene rows', () => {
  const f = fixture({ placeholder: true });
  assert.equal(f.list.children.length, 0);
  f.renderer.sync([piece('a'), piece('b')], ['b']);
  const row = f.list.children[1]; f.document.activeElement = row; f.reset();
  f.renderer.sync([piece('a'), piece('b', { name: 'Renamed' })], ['b']);
  assert.equal(f.document.activeElement, row); assert.equal(f.stats.tree, 0);
  assert.equal(f.list.children.length, 2); assert.equal(row.children[1].textContent, 'Renamed');
  f.renderer.sync([piece('a')], []);
  assert.equal(f.document.activeElement, null); assert.equal(row.parentNode, null);
});
