import { RAIL_ASSETS } from '../dist/rail-assets.js';
import { SHOP_ASSETS } from '../dist/shop-assets.js';
import { THEME_ASSETS } from '../dist/theme-assets.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import { EditorViewport, makeGeometry } from '../dist/viewport.js';
import { TYPES } from '../dist/model.js';

const SIZES = Object.fromEntries(Object.entries(TYPES).map(([id, details]) => [id, details.size]));
const PROPS = new Set(['generator', 'radio', 'planks', 'chain', 'sandbags', 'bench', 'wheel', 'trafficcone', 'dumpster', 'pallet', ...Object.keys(THEME_ASSETS), 'sevenelevenfront', 'egypttemple', ...Object.keys(SHOP_ASSETS), ...Object.keys(RAIL_ASSETS)]);
const object = (type, extra = {}) => ({
  id: type, type, size: SIZES[type], position: [0, 0, 0],
  rotation: [0, 0, 0], color: '#a4abb5', material: 'concrete',
  visible: true, collision: true, ...extra,
});

function nativePick(piece, origin, direction) {
  const viewport = Object.create(EditorViewport.prototype);
  const data = viewport._objectData(piece);
  viewport.meshes = [{ object: piece, triangles: data.triangles }];
  viewport._geometryDirty = false;
  viewport._updateCamera = () => {};
  viewport._ray = () => ({ origin, direction });
  return viewport._hit(0, 0);
}

function frontPick(type, x, z) {
  return nativePick(object(type), [x, -SIZES[type][1] / 2 - 100, z], [0, 1, 0]);
}

test('new piece geometry is deterministic, finite, and exactly contained by its declared dimensions', () => {
  for (const [type, defaults] of Object.entries(SIZES)) {
    for (const size of [defaults, [1, 1, 1], [1, 16384, 1], [16384, 1, 16384], [16384, 16384, 1], [1, 16384, 16384], [33, 79, 141]]) {
      const geometry = makeGeometry(object(type, { size }));
      assert.deepEqual(geometry, makeGeometry(object(type, { size })), type + ' deterministic');
      const points = geometry.faces.flatMap(face => face.points);
      assert.ok(points.length >= 24, type + ' nonempty geometry');
      for (const face of geometry.faces) {
        assert.equal(face.points.length, 3);
        assert.ok(face.normal.every(Number.isFinite), type + ' finite normal');
        assert.ok(Math.abs(Math.hypot(...face.normal) - 1) < 1e-8, type + ' unit normal');
      }
      for (const point of [...points, ...geometry.edges]) {
        assert.ok(point.every(Number.isFinite), type + ' finite point');
        point.forEach((n, axis) => assert.ok(Math.abs(n) <= size[axis] / 2 + 1e-6, type + ' contained axis ' + axis));
      }
      for (let axis = 0; axis < 3; axis++) {
        if (axis === 2 || !PROPS.has(type)) assert.ok(Math.abs(Math.min(...points.map(p => p[axis])) + size[axis] / 2) < 1e-6, type + ' full minimum extent');
        if (!PROPS.has(type)) assert.ok(Math.abs(Math.max(...points.map(p => p[axis])) - size[axis] / 2) < 1e-6, type + ' full maximum extent');
      }
    }
  }
});

test('native picking passes through arch and doorway openings and hits the surrounding solids', () => {
  assert.equal(frontPick('arch', 0, 0), null);
  assert.equal(frontPick('arch', 0, 96), null);
  assert.equal(frontPick('arch', 0, -170), null);
  assert.ok(frontPick('arch', 0, 173));
  assert.ok(frontPick('arch', 164, -96));
  assert.equal(frontPick('doorway', 0, 0), null);
  assert.ok(frontPick('doorway', 0, 128));
  assert.ok(frontPick('doorway', 115, 0));
});

test('L corner, diagonal beam, and fence retain their actual empty spaces when picked', () => {
  const corner = object('corner');
  assert.equal(nativePick(corner, [64, 64, 116], [0, 0, -1]), null);
  assert.equal(nativePick(corner, [0, 0, 116], [0, 0, -1]), null);
  assert.ok(nativePick(corner, [-100, 64, 116], [0, 0, -1]));
  assert.ok(nativePick(corner, [64, -100, 116], [0, 0, -1]));
  assert.ok(frontPick('beam', 0, 0));
  assert.equal(frontPick('beam', -102, 77), null);
  assert.equal(frontPick('fence', 38.4, -56), null);
  assert.ok(frontPick('fence', 0, -56));
  assert.ok(frontPick('fence', 38.4, -27.2));
});

test('crate contains raised diagonal braces over its inset body, rather than only a cube', () => {
  const frontBrace = frontPick('crate', 0, 0);
  const frontBody = frontPick('crate', 25.6, 0);
  assert.ok(frontBrace && frontBody);
  assert.ok(Math.abs(frontBrace.point[1] + 64) < 1e-8);
  assert.ok(Math.abs(frontBody.point[1] + 51.2) < 1e-8);
  const sideBrace = nativePick(object('crate'), [-164, 0, 0], [1, 0, 0]);
  assert.ok(Math.abs(sideBrace.point[0] + 64) < 1e-8);
});

test('translated and rotated doorway/corner openings still use transformed triangles for picking', () => {
  const doorway = object('doorway', { position: [200, -40, 300], rotation: [0, 0, 90] });
  assert.equal(nativePick(doorway, [332, -40, 300], [-1, 0, 0]), null);
  const lintel = nativePick(doorway, [332, -40, 428], [-1, 0, 0]);
  assert.ok(lintel);
  assert.ok(Math.abs(lintel.point[0] - 232) < 1e-8);
  const corner = object('corner', { position: [200, -40, 300], rotation: [0, 0, 90] });
  assert.equal(nativePick(corner, [136, 24, 416], [0, 0, -1]), null);
  assert.ok(nativePick(corner, [136, -140, 416], [0, 0, -1]));
});

test('all new pieces retain finite 14-float material vertices and unchanged local pulse coordinates under rotation', () => {
  const viewport = Object.create(EditorViewport.prototype);
  const materials = { checker: 1, concrete: 2, metal: 3, rust: 9, weathered: 10, 'pulse-cyan': 4, 'pulse-violet': 5, 'pulse-ember': 6, 'pulse-rainbow': 7 };
  for (const type of Object.keys(SIZES)) {
    for (const [material, pattern] of Object.entries(materials)) {
      const base = viewport._objectData(object(type, { material }));
      const moved = viewport._objectData(object(type, { material, rotation: [17, 31, 43], position: [123, -456, 789] }));
      assert.equal(moved.vertices.length, moved.triangles.length * 14, type + ' stride');
      assert.ok(moved.vertices.every(Number.isFinite), type + ' finite shader input');
      assert.equal(moved.vertices[9], pattern, type + ' material ID');
      for (let i = 0; i < moved.vertices.length; i += 14) {
        assert.deepEqual(moved.vertices.slice(i + 10, i + 14), base.vertices.slice(i + 10, i + 14), type + ' stable local attributes');
      }
    }
  }
});


test('container corrugations and door bars are raised geometry over an inset cargo body', () => {
  const [sx, sy, sz] = SIZES.container, trim = Math.min(sx, sy, sz) * .045, ribWidth = sx * .024;
  const ribX = -sx / 2 + trim + ribWidth / 2 + (sx - trim * 2 - ribWidth) * 8 / 15;
  const gap = frontPick('container', 0, 0), rib = frontPick('container', ribX, 0);
  assert.ok(gap && rib);
  assert.ok(Math.abs(gap.point[1] - (-sy / 2 + trim)) < 1e-8);
  assert.ok(Math.abs(rib.point[1] + sy / 2) < 1e-8);
  const bar = nativePick(object('container'), [sx / 2 + 100, sy * .23, 0], [-1, 0, 0]);
  const panel = nativePick(object('container'), [sx / 2 + 100, sy * .23 + 20, 0], [-1, 0, 0]);
  assert.ok(bar && panel && bar.point[0] > panel.point[0] + 1);
});

test('barrel uses a cylinder and raised hoops; truss and gate remain open with real landing decks', () => {
  assert.equal(frontPick('barrel', 47.04, 0), null);
  assert.ok(frontPick('barrel', 38.4, 0));
  assert.ok(frontPick('barrel', 47.04, 43.2));
  assert.equal(nativePick(object('truss'), [0, 0, 324], [0, 0, -1]), null);
  const deck = nativePick(object('truss'), [-SIZES.truss[0] * .22, 0, 324], [0, 0, -1]);
  assert.ok(deck);
  assert.ok(Math.abs(deck.point[2] - (-SIZES.truss[2] / 2 + SIZES.truss[2] / 3)) < 1e-8);
  assert.equal(frontPick('gate', 0, 0), null);
  assert.ok(frontPick('gate', 0, SIZES.gate[2] / 2 - SIZES.gate[2] * .085));
});

test('pipewall has separate forward pipe runs; jump pad corners and elevated ring are physical geometry', () => {
  const pipe = frontPick('pipewall', 0, 0), between = frontPick('pipewall', SIZES.pipewall[0] * .14, 0);
  assert.ok(pipe && between && pipe.point[1] < between.point[1] - 20);
  const pad = object('jumppad');
  assert.equal(nativePick(pad, [125.44, 125.44, 120], [0, 0, -1]), null);
  const center = nativePick(pad, [0, 0, 120], [0, 0, -1]);
  const ring = nativePick(pad, [SIZES.jumppad[0] * .27, 0, 120], [0, 0, -1]);
  assert.ok(center && ring);
  assert.ok(Math.abs(center.point[2] - SIZES.jumppad[2] * .45) < 1e-8);
  assert.ok(Math.abs(ring.point[2] - SIZES.jumppad[2] / 2) < 1e-8);
});

test('boost ramp arrow points toward its raised end and all arrow top vertices sit above the slope', () => {
  const [sx, sy, sz] = SIZES.boostramp, lift = sz * .025;
  const mesh = makeGeometry(object('boostramp'));
  const arrow = mesh.faces.find(face => face.emissive && face.normal[2] > .1 && face.points.some(point =>
    Math.abs(point[0]) < 1e-8 && Math.abs(point[1] - sy * .28) < 1e-8));
  assert.ok(arrow, 'uphill arrow head exists');
  assert.ok(Math.max(...arrow.points.map(point => point[1])) > Math.min(...arrow.points.map(point => point[1])));
  for (const point of arrow.points) {
    const slope = -sz / 2 + (point[1] + sy / 2) / sy * (sz - lift);
    assert.ok(Math.abs(point[2] - slope - lift) < 1e-8, 'raised arrow avoids coplanar surface');
  }
});

test('foliage recolours with the object while trunks retain brown; rock remains deterministic and lamp has open space', () => {
  const viewport = Object.create(EditorViewport.prototype);
  for (const type of ['tree', 'pine']) {
    const mesh = makeGeometry(object(type));
    const leafIndex = mesh.faces.findIndex(face => face.tint);
    assert.ok(leafIndex > 0);
    assert.ok(mesh.faces.some(face => face.color && /^#(?:795c46|80634a)$/.test(face.color)));
    const red = viewport._objectData(object(type, { color: '#cc3333' }));
    const blue = viewport._objectData(object(type, { color: '#3366cc' }));
    const offset = leafIndex * 3 * 14 + 6;
    assert.notDeepEqual(red.vertices.slice(offset, offset + 3), blue.vertices.slice(offset, offset + 3));
    assert.deepEqual(red.vertices.slice(6, 9), blue.vertices.slice(6, 9));
  }
  assert.deepEqual(makeGeometry(object('rock', { id: 'first' })), makeGeometry(object('rock', { id: 'second' })));
  assert.equal(frontPick('lamp', 0, -SIZES.lamp[2] * .2), null);
  assert.ok(makeGeometry(object('sign')).faces.some(face => face.color === '#62b9c5'));
});

test('cyan accents use static self-lit material vertices; object pulse materials override them without changing layout', () => {
  const viewport = Object.create(EditorViewport.prototype);
  viewport._upload = () => {};
  viewport.selectedIds = [];
  for (const type of ['gate', 'pipewall', 'jumppad', 'boostramp', 'lamp']) {
    const regular = viewport._objectData(object(type, { material: 'metal' }));
    assert.ok(regular.vertices.some((n, index) => index % 14 === 9 && n === 8), type + ' static emission');
    const pulse = viewport._objectData(object(type, { material: 'pulse-violet' }));
    for (let i = 9; i < pulse.vertices.length; i += 14) assert.equal(pulse.vertices[i], 5, type + ' pulse override');
    viewport.objects = [object(type)];
    viewport._buildScene();
    assert.equal(viewport._hasPulseObjects, false, type + ' static accents must not start animation');
  }
});


test('graveyard silhouettes retain arched tablets, cross cutouts, hex coffin corners and jagged wall tops', () => {
  assert.equal(frontPick('headstone', SIZES.headstone[0] * .45, SIZES.headstone[2] * .40), null);
  assert.ok(frontPick('headstone', 0, SIZES.headstone[2] * .40));
  assert.equal(frontPick('cross', SIZES.cross[0] * .45, SIZES.cross[2] * .40), null);
  assert.ok(frontPick('cross', 0, SIZES.cross[2] * .45));
  assert.equal(nativePick(object('coffin'), [SIZES.coffin[0] * .49, -SIZES.coffin[1] * .45, 180], [0, 0, -1]), null);
  assert.ok(nativePick(object('coffin'), [0, 0, 180], [0, 0, -1]));
  assert.equal(frontPick('brokenwall', SIZES.brokenwall[0] * .45, SIZES.brokenwall[2] * .40), null);
  assert.ok(frontPick('brokenwall', -SIZES.brokenwall[0] * .125, SIZES.brokenwall[2] * .45));
});

test('plots have recessed dirt and crypt/gate/fence openings admit rays through their entrances', () => {
  const grave = object('grave'), [sx, , sz] = SIZES.grave;
  const dirt = nativePick(grave, [0, 0, 148], [0, 0, -1]);
  const rim = nativePick(grave, [sx * .44, 0, 148], [0, 0, -1]);
  assert.ok(dirt && rim);
  assert.ok(Math.abs(dirt.point[2] - sz * .05) < 1e-8);
  assert.ok(Math.abs(rim.point[2] - sz / 2) < 1e-8);
  const inside = frontPick('crypt', 0, 0);
  assert.ok(inside && inside.point[1] > 0, 'front door reaches the back of the room');
  assert.ok(frontPick('crypt', SIZES.crypt[0] * .4, 0).point[1] < 0);
  assert.ok(makeGeometry(object('crypt')).faces.some(face => face.tint?.[0] === .35), 'recessed back wall stays darker');
  assert.equal(frontPick('cemeterygate', 0, 0), null);
  assert.equal(frontPick('cemeteryfence', SIZES.cemeteryfence[0] * .1, 0), null);
  assert.ok(frontPick('cemeteryfence', 0, 0));
});

test('bare dead tree branches, rounded crossed bones and separate skull teeth use actual geometry', () => {
  const tree = makeGeometry(object('deadtree')), [sx, sy, sz] = SIZES.deadtree;
  const points = tree.faces.flatMap(face => face.points);
  assert.ok(points.some(point => Math.abs(point[0] - sx / 2) < 1e-8));
  assert.ok(points.some(point => Math.abs(point[1] + sy / 2) < 1e-8));
  assert.ok(points.some(point => Math.abs(point[2] - sz / 2) < 1e-8));
  assert.equal(nativePick(object('deadtree'), [sx * .45, sy * .45, sz / 2 + 100], [0, 0, -1]), null);
  assert.equal(nativePick(object('bones'), [SIZES.bones[0] * .49, 0, 148], [0, 0, -1]), null);
  const roundedEnd = nativePick(object('bones'), [SIZES.bones[0] * .41, SIZES.bones[1] * .33, 148], [0, 0, -1]);
  assert.ok(roundedEnd && Math.abs(roundedEnd.point[2] - SIZES.bones[2] / 2) < 1e-8);
  const skull = makeGeometry(object('skull')), skullSize = SIZES.skull;
  const darkFaces = skull.faces.filter(face => face.color === '#272b2d');
  assert.ok(darkFaces.some(face => face.points.some(point => point[0] > skullSize[0] * .2 && point[2] > 0)));
  assert.ok(darkFaces.some(face => face.points.some(point => point[0] < -skullSize[0] * .2 && point[2] > 0)));
  assert.ok(darkFaces.some(face => face.points.some(point =>
    Math.abs(point[0]) < 1e-8 && Math.abs(point[2] + skullSize[2] * .16) < 1e-8)), 'nasal triangle exists');
  assert.equal(frontPick('skull', 0, -skullSize[2] * .48), null);
  assert.ok(frontPick('skull', skullSize[0] * .48 / 14, -skullSize[2] * .48));
  const pileDark = makeGeometry(object('skullpile')).faces.filter(face => face.color === '#272b2d');
  assert.equal(pileDark.length, darkFaces.length * 3, 'pile contains three detailed skulls');
});

test('lantern has an open cage and warm static emission; rust/weathered preserve colors and local vertex attributes', () => {
  assert.equal(frontPick('lantern', 0, SIZES.lantern[2] * .16), null);
  const mesh = makeGeometry(object('lantern'));
  assert.ok(mesh.faces.some(face => face.emissive && face.color === '#ffc878'));
  const viewport = Object.create(EditorViewport.prototype);
  viewport._upload = () => {}; viewport.selectedIds = [];
  for (const [material, expected] of [['rust', 9], ['weathered', 10]]) {
    const a = viewport._objectData(object('headstone', { material, color: '#909080' }));
    const b = viewport._objectData(object('headstone', { material, color: '#6060c0', rotation: [13, 27, 52] }));
    assert.equal(a.vertices[9], expected);
    assert.equal(b.vertices[9], expected);
    assert.notDeepEqual(a.vertices.slice(6, 9), b.vertices.slice(6, 9), 'aged material still recolours');
    assert.deepEqual(a.vertices.slice(10, 14), b.vertices.slice(10, 14), 'aged texture coordinates rotate with geometry');
    viewport.objects = [object('lantern', { material })]; viewport._buildScene();
    assert.equal(viewport._hasPulseObjects, false);
    const lantern = viewport._objectData(viewport.objects[0]);
    assert.ok(lantern.vertices.some((n, i) => i % 14 === 9 && n === 8));
  }
});

test('props dispatch keeps wheel spoke gaps, hollow chain links, pallet spaces and actual cone band faces', () => {
  const angle = Math.PI / 8, [sx, , sz] = SIZES.wheel;
  assert.equal(frontPick('wheel', sx * .24 * Math.cos(angle), sz * (.24 * Math.sin(angle) - .02)), null);
  assert.ok(frontPick('wheel', sx * .42 * Math.cos(angle), sz * (.42 * Math.sin(angle) - .02)));
  assert.ok(frontPick('wheel', 0, -sz * .02));
  assert.equal(nativePick(object('chain'), [SIZES.chain[0] * .28, 0, 140], [0, 0, -1]), null);
  assert.equal(frontPick('pallet', SIZES.pallet[0] * .17, 0), null);
  const coneMesh = makeGeometry(object('trafficcone'));
  const bodyFace = coneMesh.faces.findIndex(face => face.tint);
  const whiteFace = coneMesh.faces.findIndex(face => face.color === '#ded9c8');
  const rubberFace = coneMesh.faces.findIndex(face => face.color === '#353b36');
  assert.ok(bodyFace >= 0 && whiteFace >= 0 && rubberFace >= 0);
  const viewport = Object.create(EditorViewport.prototype);
  const redCone = viewport._objectData(object('trafficcone', { color: '#cc3333' }));
  const blueCone = viewport._objectData(object('trafficcone', { color: '#3366cc' }));
  const faceRGB = (data, index) => data.vertices.slice(index * 3 * 14 + 6, index * 3 * 14 + 9);
  assert.notDeepEqual(faceRGB(redCone, bodyFace), faceRGB(blueCone, bodyFace), 'cone body follows object colour');
  assert.deepEqual(faceRGB(redCone, whiteFace), faceRGB(blueCone, whiteFace), 'reflective stripe remains white');
  assert.deepEqual(faceRGB(redCone, rubberFace), faceRGB(blueCone, rubberFace), 'rubber base retains its fixed colour');
  viewport.objects = [object('chain')]; viewport.selectedIds = ['chain']; viewport._upload = () => {};
  assert.doesNotThrow(() => viewport._buildScene(), 'dense chain geometry must avoid large argument-spread limits');
  assert.ok(viewport.solidCount > 4000 && viewport.selectedCount > 0);
});

