# Editor reference

This document describes the current local prototype. Planned external game export and hosted compilation are described in the root README.

## Source layout

- `dist/app.js`: editor UI, imports, downloads, history, selection and browser drafts.
- `dist/model.js`: project schema, validation, asset registry and history snapshots.
- `dist/viewport.js`: native WebGL rendering, procedural geometry, picking and manipulation.
- `dist/surf.js`: parameterized ramp sections, dimensions and circular bends.
- `dist/paint.js`: surface painting geometry and budgets.
- `dist/triangle-tree.js`: spatial acceleration for triangle queries.
- `dist/build-tools.js`: alignment, arrays, grounding and span construction.
- `dist/scene-list.js`: stable scene rows and selection updates.
- `dist/playtest.js`: playtest dialog, controls and lifecycle.
- `dist/playtest-physics.js`: player simulation and collision.
- `dist/playtest-config.js`: saved spawn/movement validation.
- `dist/course-projects.js`: independent browser-draft keys for bundled courses.
- `dist/maps/`: Terminal Five generation, scenery, guide and bundled project.
- `dist/*-assets.js` and `dist/*-geometry.js`: themed definitions and procedural meshes.
- `dist/assets/`: bundled skybox, thumbnails and asset reference sheets.

## Geometry and assets

Coordinates use X/Y horizontally and Z vertically. Object position is its centre and size is its full extent. Rotations are degrees about X, Y and Z. Compound assets are a single selectable object; their internal furnishings are not independent editor objects.

The surf ramp is a closed wedge following one circular bend. Bend is limited to 150 degrees and further constrained by width and length. Shape edits retain its base plane. This is not arbitrary mesh sculpting. Surface paint follows the object's transforms and ramp shape.

The 7-Eleven-inspired facade has an open central entry and models the front only. At default size it is 1536 x 128 x 384 units, faces local -Y, and leaves the interior to be built toward +Y. Window panes are stylized opaque surfaces.

The Egyptian temple hall is 1792 x 3072 x 640 units by default. It has two gateways, a cutaway roof, eight columns and thirteen central landings, with furnishings in the side bays. Its geometry contains 10,524 triangles. Geometric clearance does not guarantee a route works with a target game's physics.

Rail vehicles and straight tracks run along local Y. At default width the gauge is 160 units. Straight track is 40 units high; raise a train accordingly to rest its wheels on the rail tops. Scale connected rails and trains consistently. The carriage has an open aisle, open ends and roof cutaway.

The local skybox is an AI-generated 1774 x 887 equirectangular PNG. Its generation prompt is stored alongside the asset. It is bundled rather than downloaded at runtime. The remaining models are procedural geometry rather than imported model packages.

## Project validation and history

A version 2 project stores format, version, name, objects and environment, with optional playtest configuration. Version 1 migrates to the current environment structure. Object fields are validated against an allowlist; dimensions, positions, rotations, colours and asset/material identifiers have bounds or allowed values.

The import limit is 8 MB and 2,000 objects. Paint has limits of 256 strokes and 4,096 points per object, and 20,000 points per project. History retains the initial state and the newest 59 edits. These limits reduce accidental overload but do not impose a universal geometry-memory budget.

Ordinary projects use `bhop-builder:local-draft:v1`; Terminal Five uses `bhop-builder:course:terminal-five:v1`. Browser storage is origin-specific. Save downloads a validated project with a sanitized filename; Open parses a selected file. This is not game export.

## Movement preview

The player uses a 32 x 32 x 72 upright collision box, with position representing feet. Collision sweeps against actual visible, collision-enabled triangles through spatial trees. The simulation uses fixed 120 Hz steps with a bounded catch-up interval.

Default ground speed is 320, gravity 800, jump impulse 301 and air acceleration 100. These values are configurable. Total speed is capped at 3,500 units/second. Camera eye height is 64 units above the feet and first-person FOV is 80 degrees. These settings are an approximation, not a claim of CS2 movement parity.

Spawn clearance is checked before starting. Losing focus, hiding the page or losing WebGL pauses play. Falling more than 2,048 units below the lowest solid asset resets the player. Editing helpers do not become collision objects. The editor camera and selection are restored after playtesting.

The conceptual movement reference is Valve's [published Source SDK movement code](https://github.com/ValveSoftware/source-sdk-2013/blob/master/src/game/shared/gamemovement.cpp). The editor does not bundle that SDK or require it at runtime.

## Maintenance notes

The current frontend is directly maintained in `dist`; there is no bundler or generated application build to recover from another source directory. Preserve these files when preparing the repository.

Thumbnail and sample-map scripts overwrite their known bundled outputs. Run them deliberately and review changed files. Do not overwrite an example map with a personal project without first saving a separate backup.
